import java.util.ArrayList;
public class Scuola {

	private ArrayList<Studente> studenti;
	
	public Scuola(){}
	public Scuola (ArrayList<Studente>studente ) {
		
		this.studenti = studenti;
	}
	public void setStudenti(ArrayList<Studente> studenti) {
		this.studenti = studenti;
	}
	public int getPromossi() {
		int studentiPromossi = 0;
		for (Studente stud : this.studenti) {
			if(stud.promosso() == true) {
				studentiPromossi ++;
			}
		}
		return studentiPromossi;
	}
	public void getStudenti() {
		for (Studente stud : this.studenti) {
			System.out.println(stud.toString());
		}
	}
	public Studente getstudenteMigliore() {
		Studente studMax = this.studenti.get(0);
		double mediaMax = 0 ;
		for (Studente stud : this.studenti) {
			double mediaStud = 0 ;
			for (String i : stud.getVoti().keySet()) {
				mediaStud += stud.mediaVotoMateria(i);
			}
			if (mediaStud > mediaMax) {
				mediaMax = mediaStud;
				studMax = stud;
			}
		}
		return studMax;
	}
}
