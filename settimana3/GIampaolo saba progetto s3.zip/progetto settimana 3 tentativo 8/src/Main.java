import java.util.ArrayList;
import java.util.HashMap;

public class Main {
		public static void main(String[] args) {
			
		

		//hashmap sezioni scuola
		HashMap<String,ArrayList<Double>> votiStudenti = new HashMap<>();
		
		//arraylist voti
		ArrayList<Double> votiLatino = new ArrayList<>();
		ArrayList<Double> votiScienze = new ArrayList<>();
		ArrayList<Double> votiFisica = new ArrayList<>();
		ArrayList<Double> votiReligione = new ArrayList<>();
		
		Double voto = new Double(2.0);
		Double voto2 = new Double(7.0);
		Double voto3 = new Double(6.0);
		Double voto4 = new Double(9.0);
		votiLatino.add(voto);
		votiLatino.add(voto2);
		votiLatino.add(voto3);
		
	
		//hashmap materie/voti
		votiStudenti.put("Latino" , votiLatino );
		votiStudenti.put("Scienze" , votiScienze );
		votiStudenti.put("Fisica" , votiFisica );
		votiStudenti.put("Religione" , votiReligione );
		
		//studenti 
		Studente studente1 = new Studente(2, "Paolo","Saba",'M', votiStudenti);
		Studente studente2 = new Studente(3, "Carlo","Loi",'M', votiStudenti);
		Studente studente3 = new Studente(5, "Giulia","Manca",'F', votiStudenti);
		Studente studente4 = new Studente(6, "Francesca","Sois",'F', votiStudenti);
		Studente studente5 = new Studente(9, "Nello","Paba",'M', votiStudenti);
		Studente studente6 = new Studente(11, "Paola","Carta",'F', votiStudenti);
		Studente studente7 = new Studente(23, "Omar","Loi",'M', votiStudenti);
		Studente studente8 = new Studente(87, "Chiara","Moccia",'F', votiStudenti);
		Studente studente9 = new Studente(34, "Claudia","Floris",'F', votiStudenti);
		Studente studente10 = new Studente(76, "Marco","Poba",'M', votiStudenti);
		
		ArrayList<Studente>studenti= new ArrayList<>();
		studenti.add(studente2);
		studenti.add(studente10);
		studenti.add(studente8);
		studenti.add(studente5);
		studenti.add(studente3);
		//scuola1 
		Scuola scuola = new Scuola(studenti);
		
		ArrayList<Studente>studenti2= new ArrayList<>();
		studenti.add(studente1);
		studenti.add(studente4);
		studenti.add(studente9);
		studenti.add(studente6);
		studenti.add(studente7);
		//scuola2
		Scuola scuola2 = new Scuola(studenti2);
		
		System.out.println(studente1.mediaVotoMateria("Latino"));
		
		}
		
	}

