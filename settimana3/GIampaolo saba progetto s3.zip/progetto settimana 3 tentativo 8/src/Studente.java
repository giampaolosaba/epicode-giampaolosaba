import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
public class Studente {

	private int id;
	private String nome;
	private String cognome;
	private char genere;
	private HashMap<String, ArrayList<Double>> voti;
	
	public Studente () {}
	public Studente (int id, String nome,String cognome,char genere,HashMap <String,ArrayList<Double>>voti) {
		this.id=id;
		this.nome=nome;
		this.cognome= cognome;
		this.genere = genere;
		this.voti=voti;
	}
	//getter
	public int getId() {return id;}
	public String getNome() {return nome;}
	public String getCognome() {return cognome;}
	public char getGenere() {return genere;}
	public HashMap<String, ArrayList<Double>> getVoti() {return voti;}
	//setter
	public void setId(int id) {this.id = id;}
	public void setNome(String nome) {this.nome = nome;}
	public void setCognome(String cognome) {this.cognome = cognome;}
	public void setGenere(char genere) {this.genere = genere;}
	public void setVoti(HashMap<String, ArrayList<Double>> voti) {this.voti = voti;}
	
	public double mediaVotoMateria(String materia) {
		ArrayList<Double> votiMateria = new ArrayList<>(voti.get(materia));
		double somma = 0 ;
		for (double voto:votiMateria) {
			somma += voto;
		}
		return somma / votiMateria.size();
	}
	public double votiMiglioreMateria (String materia) {
		ArrayList<Double> votiMateria = new ArrayList<>(voti.get(materia));
		double votoMigliore = votiMateria.get(0);
		for (Double voto: votiMateria) {
			if(votoMigliore<voto) {
				votoMigliore=voto;
			}
		}
		return votoMigliore;
	}
	boolean promosso() {
		int materiaInsufficienti=0;
		for(String i : this.voti.keySet()) {
			if(mediaVotoMateria(i) < 6) {
				materiaInsufficienti ++;
			}
		}
		if (materiaInsufficienti >= 4 ) {
			return false;
		}
		return true;
	}
	public String toString() {
		return "Studente numero : " + id + "\n nome e cognome :"+nome +""+ cognome+""+"("+genere+")";
	}
}
