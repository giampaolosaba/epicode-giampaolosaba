
package jdbc;

import java.util.Scanner;

import poliziaMunicipale.*;

public class Main {



	public static void main(String[] args) {



		System.out.println();
		System.out.println("Scegli cosa vuoi fare tra le seguenti opzioni \n"
				+ "1: METTI DATI AUTO \n" 
				+ "2: METTI DATI INFRAZIONE \n"
				+ "3: VEDI TUTTE LE AUTO \n"
				+ "4: CERCA AUTO DALLA TARGA \n"
				+ "5: VEDI DATI INFRAZIONE \n"
				+ "6: CANCELLA INFRAZIONE");
		Scanner scannerScelta = new Scanner (System.in);
		int scelta = scannerScelta.nextInt();
		switch(scelta) {


		case 1:
			Scanner scanner = new Scanner(System.in);
			AutoDAO auto = new AutoDAO();
			System.out.println(" INIZIALIZZA LA MACCHINA");
			System.out.println("metti la targa  ");
			Scanner scannertarga = new Scanner (System.in);
			String targa = scannertarga.next();
			System.out.println("metti la marca ");
			Scanner scannermarca = new Scanner (System.in);
			String marca = scannermarca.next();
			System.out.println("metti il modello  ");
			Scanner scannermodello = new Scanner (System.in);
			String modello = scannermodello.next();
			Auto auto2 = new Auto(targa, marca, modello);
			auto.inserisciAuto(auto2);
			break;



		case 2:

			InfrazioneDAO infrazioni = new InfrazioneDAO();
			System.out.println("INZIALIZZA L'INFRAZIONE");
			System.out.println("inserisci id infrazione");
			Scanner scannerid = new Scanner (System.in);
			int id = scannerid.nextInt();
			System.out.println("inserisci la data ");
			Scanner scannerdata= new Scanner (System.in);
			String data = scannerdata.next();
			System.out.println("inserisci tipo  ");
			Scanner scannertipo = new Scanner (System.in);
			String tipo = scannertipo.next();
			System.out.println("inserisci importo  ");
			Scanner scannerimporto = new Scanner (System.in);
			double importo = scannerimporto.nextDouble();
			System.out.println("inserisci la targa ");
			Scanner scannerauto_targa = new Scanner (System.in);
			String auto_targa = scannerauto_targa.next();
			Infrazione infrazione1 = new Infrazione(id, data, tipo, importo, auto_targa);
			infrazioni.inserisciInfrazione(infrazione1);
			break;

		case 3:
			AutoDAO autoMax = new AutoDAO();
			autoMax.getAllAuto();
			break;

		case 4:
			AutoDAO autoTarga = new AutoDAO();
			autoTarga.cercaAuto("");
			break;
		case 5:
			InfrazioneDAO infrazioni2 = new InfrazioneDAO();
			infrazioni2.stampaDatiInfrazioniAuto();
			break;
		case 6:
			InfrazioneDAO infrazioniId = new InfrazioneDAO();
			id= 0;
			infrazioniId.eliminaInfrazione(id);
			break;
		}

	}
}




