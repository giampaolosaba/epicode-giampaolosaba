package poliziaMunicipale;

public class Infrazione {
private int id;
private String data;
private String tipo;
private double importo;
private String auto_targa;


public Infrazione() {}


public Infrazione(int id, String data, String tipo, double importo, String auto_targa) {
	this.id = id;
	this.data = data;
	this.tipo = tipo;
	this.importo = importo;
	this.auto_targa = auto_targa;
}


public int getId() {
	return id;
}


public String getData() {
	return data;
}


public String getTipo() {
	return tipo;
}


public double getImporto() {
	return importo;
}


public String getAuto_targa() {
	return auto_targa;
}
public void setData(String data) {
	this.data = data;
}


public void setTipo(String tipo) {
	this.tipo = tipo;
}


public void setImporto(double importo) {
	this.importo = importo;
}


public void setAuto_targa(String auto_targa) {
	this.auto_targa = auto_targa;
}



}
