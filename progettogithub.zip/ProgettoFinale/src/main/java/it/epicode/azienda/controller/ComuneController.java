package it.epicode.azienda.controller;



import javax.validation.Valid;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import it.epicode.azienda.dto.EliminaComuneRequestDTO;
import it.epicode.azienda.dto.InserisciComuneRequestDTO;
import it.epicode.azienda.dto.InserisciProvinciaRequestDTO;
import it.epicode.azienda.dto.ModificaComuneRequestDTO;
import it.epicode.azienda.errors.ElementAlreadyPresentException;
import it.epicode.azienda.errors.NotFoundException;
import it.epicode.azienda.services.ComuneService;
import lombok.extern.slf4j.Slf4j;
@Slf4j
@RestController
@RequestMapping("/comune")
public class ComuneController {


	@Autowired
	ComuneService comuneService;
	@Operation (summary = "Inserisce un comune nel db", description = "inserisce un comune nel db ")
	@ApiResponse(responseCode = "200" , description = "fattura inserita con successo nel db !")
	@ApiResponse(responseCode ="401,403" , description = "Not Authenticated or you may have not role for this! ")
	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@PostMapping(path = "/inseriscicomune" ,produces = MediaType.TEXT_PLAIN_VALUE)
	public ResponseEntity inserisciComune(@Valid @RequestBody InserisciComuneRequestDTO dto) throws NotFoundException, ElementAlreadyPresentException {
		log.info("===========================================siamo nel controller inserisci comune ===========================================");
		comuneService.inserisciComune(dto);
		return ResponseEntity.ok("COMUNE INSERITO");
	}

	@Operation (summary = "elimina un comune presente nel db", description = "elimina un comune presente nel db ")
	@ApiResponse(responseCode = "200" , description = "eliminazione avvenuta")
	@ApiResponse(responseCode ="401,403" , description = "Not Authenticated or you may have not role for this! ")
	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@DeleteMapping("/eliminacomune")
	public ResponseEntity eliminaComune(@Valid @RequestBody EliminaComuneRequestDTO dto ) throws NotFoundException {
		log.info("===========================================siamo nel controller elimina comune ===========================================");
		comuneService.eliminaComune(dto);
		return ResponseEntity.ok("COMUNE ELIMINATO");
	}
	@Operation (summary = "modifica un comune presente nel db ", description = "modifica un comune presente nel db ")
	@ApiResponse(responseCode = "200" , description = "modifica avvenuta")
	@ApiResponse(responseCode ="401,403" , description = "Not Authenticated or you may have not role for this! ")
	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@PutMapping("/modificacomune")
	public ResponseEntity modificaComune(@Valid @RequestBody ModificaComuneRequestDTO dto) throws NotFoundException {
		log.info("===========================================siamo nel controller modifica comune ===========================================");
		comuneService.modificaComune(dto);
		return ResponseEntity.ok("COMUNE MODIFICATO");
	}
	@Operation (summary = "ritorna tutte i comuni   presenti nel db", description = "ritorna la lista di tutti i comuni presenti nel db ")
	@ApiResponse(responseCode = "200" , description = "lista clienti")
	@ApiResponse(responseCode ="401" , description = "Not Authenticated")
	@PreAuthorize("isAuthenticated()")
	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("/tutticomuni")
	public ResponseEntity tuttiComuni(Pageable page) {
		log.info("===========================================siamo nel controller cerca tutti i comuni ===========================================");
		return ResponseEntity.ok(comuneService.cercaComune(page));
	}

	@Operation (summary = "ritorna tutti i comuni per nome presenti nel db", description = "ritorna la lista di tutti i comuni per nome presenti nel db ")
	@ApiResponse(responseCode = "200" , description = "lista clienti")
	@ApiResponse(responseCode ="401" , description = "Not Authenticated")
	@PreAuthorize("isAuthenticated()")
	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("/tutticomuninome/{nome}")
	public ResponseEntity tuttiComuneNome(@PathVariable("nome")String nome,Pageable page) {
		log.info("===========================================siamo nel controller cerca comune per nome ===========================================");
		return ResponseEntity.ok(comuneService.cercaComuneNome(page,nome));
	}




}
