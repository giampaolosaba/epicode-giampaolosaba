package it.epicode.azienda.services;

import java.math.BigDecimal;
import java.time.LocalDate;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import it.epicode.azienda.dto.CambiaStatoFatturaRequestDTO;
import it.epicode.azienda.dto.CercaPerAnnoResponseDTO;
import it.epicode.azienda.dto.CercaPerDataResponseDTO;
import it.epicode.azienda.dto.EliminaFatturaRequestDTO;
import it.epicode.azienda.dto.InserisciFatturaRequestDTO;
import it.epicode.azienda.dto.ModificaFatturaRequestDTO;
import it.epicode.azienda.errors.NotFoundException;
import it.epicode.azienda.model.Cliente;
import it.epicode.azienda.model.Fattura;
import it.epicode.azienda.repository.ClienteRepository;
import it.epicode.azienda.repository.FatturaRepository;
import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class FatturaService {
	@Autowired
	FatturaRepository fr;
	@Autowired
	ClienteRepository cr;

	/**
	 * inserisce la fattura attraverso il dto con associazione cliente attraverso il request mapping POST
	 * @param dto
	 * @throws NotFoundException
	 */
	public void inserisciFattura(InserisciFatturaRequestDTO dto) throws NotFoundException {
		log.info("========================siamo nel service inserisci fattura===============");
		log.info("data " + dto.getData().toString());
		log.info("importo "+ dto.getImporto());
		log.info("stato fattura "+ dto.getStatoFattura());
		Fattura fattura = new Fattura();
		BeanUtils.copyProperties(dto, fattura);
		if(cr.existsById(dto.getIdCliente())) {
			log.info("id cliente  " + dto.getIdCliente().toString());
			Cliente cliente = cr.findById(dto.getIdCliente()).get();
			fattura.setCliente(cliente);
			cliente.getFattura().add(fattura);
			fr.save(fattura);

		}
		else {
			throw new NotFoundException("fattura non trovata");
		}

	}

	/**
	 * modifica della fattura con associazione del cliente attraverso il request mapping PUT
	 * @param dto
	 * @throws NotFoundException
	 */
	public void modificaFattura(ModificaFatturaRequestDTO dto) throws NotFoundException {
		log.info("========================siamo nel service modifica fattura===============");
		if(fr.existsById(dto.getNumero())) {
			log.info("numero fattura " + dto.getNumero().toString());
			log.info("data " + dto.getData().toString());
			log.info("importo "+ dto.getImporto());
			log.info("stato fattura "+ dto.getStatoFattura());
			Fattura fattura = fr.findById(dto.getNumero()).get();
			BeanUtils.copyProperties(dto, fattura);
			if(cr.existsById(dto.getIdCliente())) {
				log.info("id cliente "+ dto.getIdCliente().toString());
				Cliente cliente = cr.findById(dto.getIdCliente()).get();
				fattura.setCliente(cliente);
				cliente.getFattura().add(fattura);
				fr.save(fattura);
			}else {
				throw new NotFoundException("cliente non trovato");
			}
		}else {
			throw new NotFoundException("fattura non trovata");
		}

	}

	/**
	 * elimina una fattura nel db attraverso il request mapping delete
	 * @param dto
	 * @throws NotFoundException
	 */
	public void eliminaFattura(EliminaFatturaRequestDTO dto) throws NotFoundException {
		log.info("========================siamo nel service elimina fattura===============");
		if(fr.existsById(dto.getNumero())) {
			log.info("numero fattura " + dto.getNumero().toString());
			Fattura fattura = fr.findById(dto.getNumero()).get();
			fr.delete(fattura);
		}
		else {
			throw new NotFoundException("fattura non trovata");
		}	
	}

	/**
	 * ricerca di tutte le fatture con possibilita di paginazione attraverso il request mapping GET
	 * @param page
	 * @return
	 */
	public Page cercaFattura(Pageable page) {
		log.info("========================siamo nel service cerca fattura===============");
		return fr.findAll(page);

	}
	/**
	 * ricerca di tutti i clienti con associata almeno una fattura con possibilita di paginazione utilizzando request mapping GET
	 * @param page
	 * @return
	 */
	public Page cercaClienti(Pageable page) {
		log.info("========================siamo nel service cerca fattura con associato cliente===============");
		return fr.findAllByCliente(page);
	}

	/**
	 * ricerca del cliente con associata almeno una fattura con ricerca dell'id con possibilita di paginazione utilizzando il request mapping GET
	 * @param id
	 * @param page
	 * @return
	 */
	public Page cercaClienteid(Long id, Pageable page) {
		log.info("========================siamo nel service cerca fattura con associato cliente tramite id===============");
		log.info("id cliente " + id.toString() );
		return fr.findByClienteId(id, page);
	}

	/**
	 * ricerca della fattura attraverso la ricerca dello stato fattura con possibilita utilizzando il request mapping GET
	 * @param statoFattura
	 * @param page
	 * @return
	 */
	public Page cercaStatoFattura(String statoFattura,Pageable page) {
		log.info("========================siamo nel service cerca fattura per stato===============");
		log.info(statoFattura);
		return fr.findByStatoFattura(statoFattura, page);

	}
	/**
	 * ricerca della fattura attraverso la data utilizzando un dto con possibilita di paginazione utilizzando il request mapping POST
	 * @param dto
	 * @param page
	 * @return
	 */
	public Page cercaPerData(CercaPerDataResponseDTO dto, Pageable page) {
		log.info("========================siamo nel service cerca fattura per data===============");
		log.info("data " + dto.getData().toString());
		return fr.findByData(dto.getData(), page);
	}

	/**
	 * ricerca della fattura attraverso l'importo con possibilita di paginazione utilizzando il request mapping GET
	 * @param importo
	 * @param page
	 * @return
	 */
	public Page cercaPerImporto(BigDecimal importo,Pageable page) {
		log.info("========================siamo nel service cerca fattura per importo===============");
		log.info("importo inserito" + importo.toString());
		return fr.findByImporto(importo, page);
	}

	/**
	 * ricerca fattura attraverso il range di importo utilizzando una query nel repository con possibilita di paginazione utilizzando il request mapping GET
	 * @param importo
	 * @param importo2
	 * @param page
	 * @return
	 */
	public Page cercaPerRangeImporto(BigDecimal importoMin,BigDecimal importoMax, Pageable page) {
		log.info("========================siamo nel service cerca fattura per range importo===============");
		log.info("importo minimo " + importoMin.toString() + " importo max" + importoMax.toString());
		return fr.findAllByImporto(importoMin, importoMax, page);
	}
	/**
	 * ricerca fattura attraverso l'anno utilizzando una query nel repository con possibilita di paginazione utilizzando il request mapping GET
	 * @param dto
	 * @param page
	 * @return
	 */
	public Page cercaPerAnno(String anno, Pageable page) {
		log.info("========================siamo nel service cerca fattura anno query===============");
		log.info("anno " + anno);
		LocalDate data1 = LocalDate.parse(anno + "-01-01");
		LocalDate data2 = LocalDate.parse(anno + "-12-31");
		return fr.findByAnno(data1,data2, page);
	}

	/**
	 * ricerca fattura attraverso l'anno utilizzando una query nel repository con possibilita di paginazione utilizzando il request mapping GET
	 * @param dto
	 * @param page
	 * @return
	 */
	public Page cercaPerAnno2(Integer anno,Pageable page) {
		log.info("========================siamo nel service cerca fattura anno query===============");
		log.info("anno " + anno);
		return fr.findByAnno(anno, page);
	}

	/**
	 * cambia lo stato fattura attraverso il request mapping PUT
	 * @param dto
	 * @throws NotFoundException
	 */
	public void cambiaStatoFattura(CambiaStatoFatturaRequestDTO dto) throws NotFoundException {
		log.info("========================siamo nel service cambia stato fattura===============");
		if(fr.existsById(dto.getNumero())) {
			log.info("numero fattura" + dto.getNumero().toString());
			log.info("sato fattura " + dto.getStatoFattura());
			Fattura f =	fr.findById(dto.getNumero()).get();
			f.setStatoFattura(dto.getStatoFattura());
			fr.save(f);
		}
		else {
			throw new NotFoundException("fattura non trovata");
		}

	}



}
