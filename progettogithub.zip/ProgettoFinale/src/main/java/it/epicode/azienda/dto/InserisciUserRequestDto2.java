package it.epicode.azienda.dto;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;


import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class InserisciUserRequestDto2 {
 @NotBlank
	private String username;
@NotBlank
	private String password;
@NotBlank
	private String email;
	private String roles ;
	 private String nome;
	 private String cognome;
	
	

}
