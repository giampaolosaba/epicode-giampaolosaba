package it.epicode.azienda.model;

public enum ECliente {
	PA,
	SAS,
	SPA,
	SRL;

}
