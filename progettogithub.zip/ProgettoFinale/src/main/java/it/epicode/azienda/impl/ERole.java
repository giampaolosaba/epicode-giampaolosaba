package it.epicode.azienda.impl;

public enum ERole {
	ROLE_USER,
	ROLE_ADMIN
	;
}
