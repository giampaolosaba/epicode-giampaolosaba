package it.epicode.azienda.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import it.epicode.azienda.dto.EliminaSedeLegaleRequestDTO;
import it.epicode.azienda.dto.InserisciSedeLegaleRequestDTO;
import it.epicode.azienda.dto.ModificaSedeLegaleRequestDTO;
import it.epicode.azienda.errors.ElementAlreadyPresentException;
import it.epicode.azienda.errors.NotFoundException;
import it.epicode.azienda.services.SedeLegaleService;
import lombok.extern.slf4j.Slf4j;
@Slf4j
@RestController
@RequestMapping("/sedelegale")
public class SedeLegaleController {


	@Autowired
	SedeLegaleService sedeLegaleService;


	@Operation (summary = "Inserisce una sede legale nel db", description = "Inserisce una sede legale nel db")
	@ApiResponse(responseCode = "200" , description = "sede legale inserito con successo nel db !")
	@ApiResponse(responseCode ="401,403" , description = "Not Authenticated or you may have not role for this! ")
	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@PostMapping(path = "/inseriscisedelegale" ,produces = MediaType.TEXT_PLAIN_VALUE)
	public ResponseEntity inserisciSedeLegale(@Valid @RequestBody InserisciSedeLegaleRequestDTO dto) throws NotFoundException, ElementAlreadyPresentException {
		log.info("===========================================siamo nel controller inserisciSedeLegale ===========================================");
		sedeLegaleService.inserisciSedeLegale(dto);
		return ResponseEntity.ok("SEDE LEGALE INSERITA");
	}

	@Operation (summary = "modifica una sede legale presente nel db ", description = "modifica una sede legale presente nel db ")
	@ApiResponse(responseCode = "200" , description = "modifica avvenuta")
	@ApiResponse(responseCode ="401,403" , description = "Not Authenticated or you may have not role for this! ")
	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@PutMapping("/modificasedelegale")
	public ResponseEntity modificaSedeLegale(@Valid @RequestBody ModificaSedeLegaleRequestDTO dto) throws NotFoundException {
		log.info("===========================================siamo nel controller modificaSedeLegale ===========================================");
		sedeLegaleService.modificaSedeLegale(dto);
		return ResponseEntity.ok("SEDE LEGALE MODIFICATA");
	}


	@Operation (summary = "elimina una sede legale presente nel db", description = "elimina una sede legale presente nel db ")
	@ApiResponse(responseCode = "200" , description = "eliminazione avvenuta")
	@ApiResponse(responseCode ="401,403" , description = "Not Authenticated or you may have not role for this! ")
	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@DeleteMapping("/eliminasedelegale")
	public ResponseEntity eliminaSedeLegale(@Valid @RequestBody EliminaSedeLegaleRequestDTO dto ) throws NotFoundException {
		log.info("===========================================siamo nel controller eliminaSedeLegale ===========================================");
		sedeLegaleService.eliminaSedeLegale(dto);
		return ResponseEntity.ok("SEDE LEGALE ELIMINATA");
	}


	@Operation (summary = "ritorna tutte sede legali  presenti nel db", description = "ritorna tutte sede legali  presenti nel db ")
	@ApiResponse(responseCode = "200" , description = "lista clienti")
	@ApiResponse(responseCode ="401" , description = "Not Authenticated")
	@PreAuthorize("isAuthenticated()")
	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("/tuttesedilegali")
	public ResponseEntity tutteSediLegali(Pageable page) {
		log.info("===========================================siamo nel controller tutteSediLegali ===========================================");
		return ResponseEntity.ok(sedeLegaleService.cercaSedeLegale(page));
	}

	@Operation (summary = "ritorna tutte sede legali tramite ricerca della via presenti nel db", description = "ritorna tutte sede legali  presenti nel db ")
	@ApiResponse(responseCode = "200" , description = "lista clienti")
	@ApiResponse(responseCode ="401" , description = "Not Authenticated")
	@PreAuthorize("isAuthenticated()")
	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("/tuttesedilegalivia/{via}")
	public ResponseEntity tutteSediLegaliVia(@PathVariable("via")String via,Pageable page) {
		log.info("===========================================siamo nel controller tutteSediLegaliVia ===========================================");
		return ResponseEntity.ok(sedeLegaleService.cercaSedeLegaleVia(via,page));
	}


}
