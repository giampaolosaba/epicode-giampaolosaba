package it.epicode.azienda.controller;

import java.time.LocalDate;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import it.epicode.azienda.dto.CercaPerDataResponseDTO;
import it.epicode.azienda.dto.EliminaClienteRequestDTO;
import it.epicode.azienda.dto.InserisciClienteRequestDTO;
import it.epicode.azienda.dto.ModificaClienteRequestDTO;
import it.epicode.azienda.errors.NotFoundException;
import it.epicode.azienda.services.ClienteService;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/cliente")
@Slf4j
public class ClienteController {

	@Autowired
	ClienteService clienteService;
	@Operation (summary = "Inserisce un cliente nel db", description = "inserisce una fattura nel db ")
	@ApiResponse(responseCode = "200" , description = "cliente inserito con successo nel db !")
	@ApiResponse(responseCode ="401,403" , description = "Not Authenticated or you may have not role for this! ")
	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@PostMapping(path = "/inseriscicliente" ,produces = MediaType.TEXT_PLAIN_VALUE)
	public ResponseEntity inserisciCliente(@Valid @RequestBody InserisciClienteRequestDTO dto) throws NotFoundException {
	log.info("===========================================siamo nel controller inserisci cliente===========================================");
		clienteService.inserisciCliente(dto);
		return ResponseEntity.ok("CLIENTE INSERITO");
	}
	@Operation (summary = "modifica una cliente presente nel db ", description = "modifica un cliente presente nel db ")
	@ApiResponse(responseCode = "200" , description = "modifica avvenuta")
	@ApiResponse(responseCode ="401,403" , description = "Not Authenticated or you may have not role for this! ")
	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@PutMapping("/modificacliente")
	public ResponseEntity modificaCliente(@Valid @RequestBody ModificaClienteRequestDTO dto) throws NotFoundException {
		log.info("===========================================siamo nel controller modifica cliente===========================================");
		clienteService.modificaCliente(dto);
		return ResponseEntity.ok("CLIENTE MODIFICATO");
	}

	@Operation (summary = "elimina un  cliente presente nel db", description = "elimina un cliente presente nel db ")
	@ApiResponse(responseCode = "200" , description = "eliminazione avvenuta")
	@ApiResponse(responseCode ="401,403" , description = "Not Authenticated or you may have not role for this! ")
	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@DeleteMapping("/eliminacliente")
	public ResponseEntity eliminaCliente(@Valid @RequestBody EliminaClienteRequestDTO dto ) throws NotFoundException {
		log.info("===========================================siamo nel controller elimina cliente===========================================");
		clienteService.eliminaCliente(dto);
		return ResponseEntity.ok("CLIENTE ELIMINATO");
	}
	@Operation (summary = "ritorna tutti clienti per nome  presenti nel db", description = "ritorna la lista di tutti i clienti presenti nel db ")
	@ApiResponse(responseCode = "200" , description = "lista clienti")
	@ApiResponse(responseCode ="401" , description = "Not Authenticated")
	@PreAuthorize("isAuthenticated()")
	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("/tutticlienti")
	public ResponseEntity tuttiClienti(Pageable page) {
		log.info("===========================================siamo nel controller cerca tutti i clienti ===========================================");
		return ResponseEntity.ok(clienteService.cercaClienti(page));
	}
	@Operation (summary = "ritorna tutti clienti per nome presenti nel db", description = "ritorna la lista di tutti i clienti presenti nel db ")
	@ApiResponse(responseCode = "200" , description = "lista clienti")
	@ApiResponse(responseCode ="401" , description = "Not Authenticated")
	@PreAuthorize("isAuthenticated()")
	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("/tutticlientinome/{nomeContatto}")
	public ResponseEntity tuttiClientiNome(@PathVariable("nomeContatto")String nomeContatto,Pageable page) {
		log.info("===========================================siamo nel controller cerca cliente nome ===========================================");
		return ResponseEntity.ok(clienteService.cercaClientiNome(nomeContatto,page));
	}
	@Operation (summary = "ritorna tutti clienti per fatturato annuale presenti nel db", description = "ritorna la lista di tutti i clienti presenti nel db ")
	@ApiResponse(responseCode = "200" , description = "lista clienti")
	@ApiResponse(responseCode ="401" , description = "Not Authenticated")
	@PreAuthorize("isAuthenticated()")
	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("/tutticlientifatturatoannuale/{fatturatoAnnuale}")
	public ResponseEntity tuttiClientiFatturato(@PathVariable("fatturatoAnnuale") double fatturatoAnnuale,Pageable page) {
		log.info("===========================================siamo nel controller cerca cliente fatturato annuale ===========================================");
		return ResponseEntity.ok(clienteService.cercaClientiFatturato(fatturatoAnnuale,page));
	}
	@Operation (summary = "ritorna tutti clienti per data inserimento presenti nel db", description = "ritorna la lista di tutti i clienti presenti nel db ")
	@ApiResponse(responseCode = "200" , description = "lista clienti")
	@ApiResponse(responseCode ="401" , description = "Not Authenticated")
	@PreAuthorize("isAuthenticated()")
	@SecurityRequirement(name = "bearerAuth")
	@PostMapping ("/tutticlientidatainserimento")
	public ResponseEntity tuttiClientiDataInserimento(@Valid @RequestBody CercaPerDataResponseDTO dto,Pageable page) {
		log.info("===========================================siamo nel controller cerca cliente data inserimento ===========================================");
		return ResponseEntity.ok(clienteService.cercaClientiDataInserimento(dto,page));
	}
	@Operation (summary = "ritorna tutti clienti per data ultimo contatto presenti nel db", description = "ritorna la lista di tutti i clienti presenti nel db ")
	@ApiResponse(responseCode = "200" , description = "lista clienti")
	@ApiResponse(responseCode ="401" , description = "Not Authenticated")
	@PreAuthorize("isAuthenticated()")
	@SecurityRequirement(name = "bearerAuth")
	@PostMapping ("/tutticlientidataultimocontatto")
	public ResponseEntity tuttiClientiDataUtlimoContatto(@Valid @RequestBody CercaPerDataResponseDTO dto,Pageable page) {
		log.info("===========================================siamo nel controller cerca cliente data ultimo contatto ===========================================");
		return ResponseEntity.ok(clienteService.cercaClientiDataUltimoContatto(dto,page));
	}
	@Operation (summary = "ritorna tutti clienti per provincia della sede legale del contatto presenti nel db", description = "ritorna la lista di tutti i clienti presenti nel db ")
	@ApiResponse(responseCode = "200" , description = "lista clienti")
	@ApiResponse(responseCode ="401" , description = "Not Authenticated")
	@PreAuthorize("isAuthenticated()")
	@SecurityRequirement(name = "bearerAuth")
	@GetMapping("/cercaprovinciasedelegale/{provincia}")
	public ResponseEntity clienteSedeLegaleProvincia(@PathVariable("provincia")String provincia,Pageable page) {
		log.info("===========================================siamo nel controller cerca cliente per provincia ===========================================");
		return ResponseEntity.ok(clienteService.cercaClientePerProvincia(provincia, page));
	}




}
