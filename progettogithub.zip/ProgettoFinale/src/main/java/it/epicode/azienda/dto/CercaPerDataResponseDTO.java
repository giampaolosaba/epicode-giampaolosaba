package it.epicode.azienda.dto;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonFormat;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CercaPerDataResponseDTO {
static final String DATA_PATTERN = "dd/MM/yyyy";
@Schema(example = "20/02/2000", type = "string")
@JsonFormat(pattern = DATA_PATTERN)
private LocalDate data;
}
