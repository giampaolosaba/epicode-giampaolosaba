package it.epicode.azienda.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import it.epicode.azienda.model.SedeLegale;
import it.epicode.azienda.model.SedeOperativa;

public interface SedeLegaleRepository extends PagingAndSortingRepository<SedeLegale, Long>{

	
	Page <SedeLegale>findByViaContaining(Pageable page,String via);
	

}
