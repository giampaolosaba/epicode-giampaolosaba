package it.epicode.azienda.dto;

import java.util.List;

import it.epicode.azienda.impl.User;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CercaTuttiGliUserResponseDTO {
	private int UserTrovati;
	List<User>elencoUser;

}
