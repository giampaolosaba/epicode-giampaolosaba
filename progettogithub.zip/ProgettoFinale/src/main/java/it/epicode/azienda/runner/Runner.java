package it.epicode.azienda.runner;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import it.epicode.azienda.impl.ERole;
import it.epicode.azienda.impl.Role;
import it.epicode.azienda.impl.User;
import it.epicode.azienda.impl.UserRepository;
import it.epicode.azienda.model.Cliente;
import it.epicode.azienda.model.Comune;
import it.epicode.azienda.model.ECliente;
import it.epicode.azienda.model.Fattura;
import it.epicode.azienda.model.Provincia;
import it.epicode.azienda.model.SedeLegale;
import it.epicode.azienda.model.SedeOperativa;
import it.epicode.azienda.repository.ClienteRepository;
import it.epicode.azienda.repository.ComuneRepository;
import it.epicode.azienda.repository.FatturaRepository;
import it.epicode.azienda.repository.ProvinciaRepository;
import it.epicode.azienda.repository.SedeLegaleRepository;
import it.epicode.azienda.repository.SedeOperativaRepository;


@Component
public class Runner implements CommandLineRunner {
	
	@Autowired
	ClienteRepository clienteRepository;
	@Autowired
	ComuneRepository comuneRepository;
	@Autowired
	FatturaRepository fatturaRepository;
	@Autowired
	ProvinciaRepository provinciaRepository;
	@Autowired
	SedeLegaleRepository sedeLegale;
	@Autowired
	SedeOperativaRepository sedeOperativa;
	@Autowired
	PasswordEncoder encoder;
	@Autowired
	UserRepository ur; 
	
	
	@Override
	public void run(String... args) throws Exception {
		
		

		Provincia provincia2 = Provincia.builder().sigla("blAb").provincia("Napoli").regione("Campania").build();
		Comune comune2 = Comune.builder().nome("San Carlo").cap("099").provincia(provincia2).build();
		
		comuneRepository.save(comune2);
		
		Provincia provincia1 = Provincia.builder().sigla("BNAb").provincia("Napoli").regione("Campania").build();
		Comune comune1 = Comune.builder().nome("San_Costanzo").cap("099").provincia(provincia1).build();
		SedeOperativa sedeOperativa1 = SedeOperativa.builder().via("Via Milano").localita("Napoli").cap("09899").comune(comune1) .build();
		SedeLegale sedeLegale1 = SedeLegale.builder().via("Via Milano").localita("Napoli").cap("09899").comune(comune1).build();	
		Cliente cliente1 = Cliente.builder().ragioneSociale("Bettitelli").partitaIva("I8922T")
				.email("bettitelli@gmail.com").fatturatoAnnuale(333).pec("pec@pec.it").telefono("300948").emailContatto("luca@gmail.com").dataInserimento(LocalDate.now()).dataUltimoContatto(LocalDate.now())
				.nomeContatto("luca").cognomeContatto("bettitelli").telefonoContatto("987003").tipoCliente(ECliente.PA).sedeLegale(sedeLegale1).sedeOperativa(sedeOperativa1).build();
		Fattura fattura1 = Fattura.builder().importo(BigDecimal.valueOf(20000.00)).statoFattura("locale").data(LocalDate.now()).anno(2002)
				.cliente(cliente1).build();

		
		fatturaRepository.save(fattura1);
		
		Provincia provincia = Provincia.builder().sigla("BAFFb").provincia("Bari").regione("Puglia").build();
		Comune comune = Comune.builder().nome("Bari").cap("100").provincia(provincia).build();
		SedeOperativa sedeOperativa = SedeOperativa.builder().via("Via Como").localita("Perugia").cap("80021").comune(comune) .build();
		SedeLegale sedeLegale = SedeLegale.builder().via("Via Napoli").localita("Napoli").cap("08111").comune(comune).build();	
		Cliente cliente = Cliente.builder().ragioneSociale("Poveri & co").partitaIva("nonC'HoUnEuro")
				.email("prestami5euro@gmail.com").fatturatoAnnuale(200).pec("pec@pec.it").telefono("300948").emailContatto("duspicci@gmail.com").dataInserimento(LocalDate.now()).dataUltimoContatto(LocalDate.now())
				.nomeContatto("luca").cognomeContatto("bettitelli").telefonoContatto("987003").tipoCliente(ECliente.PA).sedeLegale(sedeLegale).sedeOperativa(sedeOperativa).build();
		Fattura fattura = Fattura.builder().importo(BigDecimal.valueOf(20000.00)).statoFattura("da pagare").data(LocalDate.now()).anno(2001)
				.cliente(cliente).build();
	
		fatturaRepository.save(fattura);
		
		Set hash = new HashSet<Role>();
		Role admin= Role.builder().roleName(ERole.ROLE_ADMIN).build();
		hash.add(admin);
		Set hash1 = new HashSet<Role>();
		Role user= Role.builder().roleName(ERole.ROLE_USER).build();
		hash1.add(user);
		User u1 = User.builder().username("Paolo23").nome("Paolo").cognome("Saba")
				.password( BCrypt.hashpw("1234", BCrypt.gensalt())).email("paole23@hotmail.it").roles(hash).accountActive(true).build();
		User u = User.builder().username("Maria").nome("Lorella").cognome("Lysogor")
				.password(encoder.encode("Sweet")).roles(hash1).email("muffin@hotmail.it").accountActive(true).build();
		
		ur.save(u);
		ur.save(u1);	
	}
	
	

	
}