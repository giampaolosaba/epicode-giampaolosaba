package it.epicode.azienda.repository;

import java.time.LocalDate;

import javax.persistence.NamedQuery;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import it.epicode.azienda.model.Cliente;

public interface ClienteRepository extends PagingAndSortingRepository<Cliente, Long>{
	
	Page<Cliente>findByNomeContattoContaining(String nomeContatto,Pageable page);
	
	Page<Cliente>findByFatturatoAnnuale(double fatturatoAnnuale,Pageable page);
	
	Page<Cliente>findByDataInserimento(LocalDate dataInserimento,Pageable page);
	
	Page<Cliente>findByDataUltimoContatto(LocalDate dataUltimoContatto,Pageable page);
	
	
	//@Query(value = "select * from Cliente join sede_legale on cliente.sede_legale=sede_legale.id "
		//	+ "join comune on sede_legale.id_comune = comune.id"
		//	+ "join provincia on comune.codice_provincia=provincia.sigla where provincia = ?1",nativeQuery = true)
	
	@Query("select cl from Cliente cl join cl.sedeLegale s join s.comune c join c.provincia p where p.provincia=?1  ")
	Page<Cliente>findByProvinciaSedeLegale(String provincia,Pageable Page);
	
}
