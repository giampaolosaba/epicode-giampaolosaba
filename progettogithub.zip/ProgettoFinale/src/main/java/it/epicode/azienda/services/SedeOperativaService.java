package it.epicode.azienda.services;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import it.epicode.azienda.dto.EliminaSedeOperativaRequestDTO;
import it.epicode.azienda.dto.InserisciSedeOperativaRequestDTO;
import it.epicode.azienda.dto.ModificaSedeOperativaRequestDTO;
import it.epicode.azienda.errors.ElementAlreadyPresentException;
import it.epicode.azienda.errors.NotFoundException;
import it.epicode.azienda.model.Comune;
import it.epicode.azienda.model.SedeOperativa;
import it.epicode.azienda.repository.ComuneRepository;
import it.epicode.azienda.repository.SedeOperativaRepository;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class SedeOperativaService {
	@Autowired
	SedeOperativaRepository sor;
	@Autowired
	ComuneRepository cr;
	

	/**
	 * inserimento di una sede operativa nel db con associazione del comune attraverso il request mapping POST
	 * @param dto
	 * @throws NotFoundException
	 * @throws ElementAlreadyPresentException
	 */
	public void inserisciSedeOperativa(InserisciSedeOperativaRequestDTO dto) throws NotFoundException {
		log.info("========================siamo nel service inserisci sede operativa ===============");
		log.info("cap "+ dto.getCap());
		log.info("localita "+ dto.getLocalita());
		log.info("via "+ dto.getVia());
		SedeOperativa sedeOperativa = new SedeOperativa();
		BeanUtils.copyProperties(dto, sedeOperativa);
		if(cr.existsById(dto.getIdComune())) {
			log.info("id comune " + dto.getIdComune().toString());
			Comune c = cr.findById(dto.getIdComune()).get();
			sedeOperativa.setComune(c);
			c.getSedeOperativa().add(sedeOperativa);
			sor.save(sedeOperativa);
		}
		else {
			throw new NotFoundException("Comune non trovato");
		}
	}

	/**
	 * modifica di una sede operativa con associazione del comune attraverso il request mapping PUT
	 * @param dto
	 * @throws NotFoundException
	 * @throws ElementAlreadyPresentException 
	 */
	public void modificaSedeOperativa(ModificaSedeOperativaRequestDTO dto ) throws NotFoundException {
		log.info("========================siamo nel service modifica sede operativa ===============");
		log.info("id sede legale " + dto.getId().toString());
		if(sor.existsById(dto.getId())) {
			log.info("cap "+ dto.getCap());
			log.info("localita "+ dto.getLocalita());
			log.info("via "+ dto.getVia());
			SedeOperativa sedeOperativa = sor.findById(dto.getId()).get();
			BeanUtils.copyProperties(dto, sedeOperativa);
			if(cr.existsById(dto.getIdComune())) {
				log.info("id comune " + dto.getIdComune().toString());
				Comune c = cr.findById(dto.getIdComune()).get();
				sedeOperativa.setComune(c);
				c.getSedeOperativa().add(sedeOperativa);
				sor.save(sedeOperativa);
			}
			else {
				throw new  NotFoundException("comune non trovato");
			}
		}
		else {
			throw new NotFoundException("sede operativa non trovata");
		}

	}

	/**
	 * eliminazione di uan sede operativa attraverso la ricerca dell'id con request mapping DELETE
	 * @param dto
	 * @throws NotFoundException
	 */
	public void eliminaSedeOperativa(EliminaSedeOperativaRequestDTO dto) throws NotFoundException {
		log.info("========================siamo nel service elimina sede operativa ===============");
		if(sor.existsById(dto.getId())) {
			log.info("id sede legale " + dto.getId());
			SedeOperativa so=sor.findById(dto.getId()).get();
			so.getCliente().setSedeOperativa(null);
			so.setCliente(null);
			so.setComune(null);
			sor.delete(so);
		}
		else {
			throw new NotFoundException("sede operativa non trovata");
		}

	}	
	/**
	 * ricerca di tutte le sede operativa con possiblita di paginazione attraverso il request mapping DELETE
	 * @param page
	 * @return
	 */
	public Page cercaSedeOperativa(Pageable page) {
		log.info("========================siamo nel service cerca tutte sede operativa ===============");
		return sor.findAll(page);

	}
	/**
	 * ricerca della sede operativa attraverso la via con possibilita di paginazione attraverso il request mapping get
	 * @param via
	 * @param page
	 * @return
	 */
	public Page cercaSedeOperativaVia(String via,Pageable page) {
		log.info("========================siamo nel service cerca sede legale per via ===============");
		log.info("via " + via);
		return sor.findByViaContaining(page, via);
	}






}
