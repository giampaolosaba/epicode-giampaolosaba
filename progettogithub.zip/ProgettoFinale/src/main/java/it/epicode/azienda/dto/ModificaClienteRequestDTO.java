package it.epicode.azienda.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonFormat;

import io.swagger.v3.oas.annotations.media.Schema;
import it.epicode.azienda.model.ECliente;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ModificaClienteRequestDTO {
	
	static final String DATE_PATTERN ="dd/MM/yyyy";
	static final String DATE_TIME_PATTERN ="dd/MM/yyyy HH:mm:ss";
	@NotNull(message = "il campo id non deve essere vuoto")
	private Long id;
	private String ragioneSociale;
	private String partitaIva;
	private String email;
	@Schema(example = "20/02/2000", type = "string")	
	@JsonFormat(pattern = DATE_PATTERN)
	private String dataInserimento;
	@Schema(example = "20/02/2000", type = "string")	
	@JsonFormat(pattern = DATE_PATTERN)
	private String dataUltimoContatto;
	@Schema(example = "Puoi inserire solo uno dei seguenti PA,SAS,SPA,SRL")
	private ECliente tipoCliente;
	private double fatturatoAnnuale;
	private String pec;
	private String telefono;
	private String emailContatto;
	private String nomeContatto;
	private String cognomeContatto;
	private String telefonoContatto;
	@NotNull(message = "il campo id sede legale non deve essere vuoto")
	private Long idSedeLegale;
	@NotNull(message = "il campo id sede operativa non deve essere vuoto")
	private Long idSedeOperativa;
	

}
