package it.epicode.azienda.provinciatest;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import it.epicode.azienda.BasicTests;
import it.epicode.azienda.dto.EliminaProvinciaRequestDTO;
import it.epicode.azienda.dto.InserisciProvinciaRequestDTO;
import it.epicode.azienda.dto.ModificaProvinciaRequestDTO;

public class ProvinciaControllerTest extends BasicTests {

	@Override
	protected String getEntryPoint() {

		return "/provincia";
	}

	@Test
	void getAllProvince() {
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tutteprovince", HttpMethod.GET,getAuthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);

	}
	@Test
	void getAllProvinceKo() {
		ResponseEntity<String> r1 = restTemplate.exchange(api() + "/tutteprovince", HttpMethod.GET,getUnauthorizedEntity(),String.class);
		assertThat(r1.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	@Test
	void getAllProvinceNotAuth() {
		ResponseEntity<String> r1 = restTemplate.exchange(api() + "/tutteprovince", HttpMethod.GET,HttpEntity.EMPTY,String.class);
		assertThat(r1.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	@Test
	void getAllProvinceNome() {
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tutteprovincenome/Na", HttpMethod.GET,getAuthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
	@Test
	void getAllProvinceNomeKo() {
		ResponseEntity<String> r1 = restTemplate.exchange(api() + "/tutteprovincenome/Na", HttpMethod.GET,getUnauthorizedEntity(),String.class);
		assertThat(r1.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	@Test
	void getAllProvinceNomeNotFound() {
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tutteprovincenome/", HttpMethod.GET,getAuthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.NOT_FOUND);
	}
	@Test
	void getAllProvinceNomeNotAut() {
		ResponseEntity<String> r1 = restTemplate.exchange(api() + "/tutteprovincenome/Na", HttpMethod.GET, HttpEntity.EMPTY,String.class);
		assertThat(r1.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}

	@Test
	void inserisciProvincia() {
		InserisciProvinciaRequestDTO dto = new InserisciProvinciaRequestDTO();
		dto.setSigla("URS");
		dto.setRegione("Putin");
		dto.setProvincia("rassian");
		HttpEntity<InserisciProvinciaRequestDTO>entity = new HttpEntity<InserisciProvinciaRequestDTO>(dto,getAuthorizedHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/inserisciprovincia",HttpMethod.POST,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);

	}
	@Test
	void inserisciProvinciaKo() {
		InserisciProvinciaRequestDTO dto = new InserisciProvinciaRequestDTO();
		dto.setSigla("URS");
		dto.setRegione("Putin");
		dto.setProvincia("rassian");
		HttpEntity<InserisciProvinciaRequestDTO>entity = new HttpEntity<InserisciProvinciaRequestDTO>(dto,getUnauthorizedRoleHeaders());
		ResponseEntity<?>r1 = restTemplate.exchange(api()+ "/inserisciprovincia",HttpMethod.POST,entity,String.class);
		assertThat(r1.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);

	}
	@Test
	void inserisciProvinciaNotAuth() {
		InserisciProvinciaRequestDTO dto = new InserisciProvinciaRequestDTO();
		dto.setSigla("URS");
		dto.setRegione("Putin");
		dto.setProvincia("rassian");
		HttpEntity<InserisciProvinciaRequestDTO>entity = new HttpEntity<InserisciProvinciaRequestDTO>(dto);
		ResponseEntity<?>r2 = restTemplate.exchange(api()+ "/inserisciprovincia",HttpMethod.POST,entity,String.class);
		assertThat(r2.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);

	}
	@Test
	void modificaProvinciaNotFound() {
		ModificaProvinciaRequestDTO dto =  new ModificaProvinciaRequestDTO();
		dto.setSigla("URS");
		dto.setProvincia("boh");
		dto.setRegione("boh2");
		HttpEntity<ModificaProvinciaRequestDTO>entity = new HttpEntity<ModificaProvinciaRequestDTO>(dto,getAuthorizedHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/modficaprovincia",HttpMethod.PUT,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.NOT_FOUND);
	}
	@Test
	void modificaProvincia() {
		ModificaProvinciaRequestDTO dto =  new ModificaProvinciaRequestDTO();
		dto.setSigla("Na");
		dto.setProvincia("boh");
		dto.setRegione("boh2");
		HttpEntity<ModificaProvinciaRequestDTO>entity = new HttpEntity<ModificaProvinciaRequestDTO>(dto,getAuthorizedHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/modficaprovincia",HttpMethod.PUT,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.NOT_FOUND);
	}





	@Test
	void eliminaProvincia() {
		EliminaProvinciaRequestDTO dto = new EliminaProvinciaRequestDTO();
		dto.setSigla("URS");
		HttpEntity<EliminaProvinciaRequestDTO>entity = new HttpEntity<EliminaProvinciaRequestDTO>(dto,getAuthorizedHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/eliminaprovincia",HttpMethod.DELETE,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);

	}
	@Test
	void eliminaProvinciaKo() {
		EliminaProvinciaRequestDTO dto = new EliminaProvinciaRequestDTO();
		dto.setSigla("URS");
		HttpEntity<EliminaProvinciaRequestDTO>entity = new HttpEntity<EliminaProvinciaRequestDTO>(dto,getUnauthorizedRoleHeaders());
		ResponseEntity<?>r1 = restTemplate.exchange(api()+ "/eliminaprovincia",HttpMethod.DELETE,entity,String.class);
		assertThat(r1.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);

	}
	void eliminaProvinciaNotAuth() {
		EliminaProvinciaRequestDTO dto = new EliminaProvinciaRequestDTO();
		dto.setSigla("URS");
		HttpEntity<EliminaProvinciaRequestDTO>entity = new HttpEntity<EliminaProvinciaRequestDTO>(dto);
		ResponseEntity<?>r2 = restTemplate.exchange(api()+ "/eliminaprovincia",HttpMethod.DELETE,entity,String.class);
		assertThat(r2.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);

	}
	void eliminaProvinciaNotFound() {
		EliminaProvinciaRequestDTO dto = new EliminaProvinciaRequestDTO();
		dto.setSigla("URS2");
		HttpEntity<EliminaProvinciaRequestDTO>entity = new HttpEntity<EliminaProvinciaRequestDTO>(dto,getAuthorizedHeaders());
		ResponseEntity<?>r3 = restTemplate.exchange(api()+ "/eliminaprovincia",HttpMethod.DELETE,entity,String.class);
		assertThat(r3.getStatusCode()).isEqualByComparingTo(HttpStatus.NOT_FOUND);


	}










}
