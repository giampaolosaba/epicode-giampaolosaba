package it.epicode.azienda.comunetest;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import it.epicode.azienda.BasicTests;
import it.epicode.azienda.dto.EliminaComuneRequestDTO;
import it.epicode.azienda.dto.InserisciComuneRequestDTO;
import it.epicode.azienda.dto.ModificaComuneRequestDTO;

public class ComuneControllerTest extends BasicTests {

	@Override
	protected String getEntryPoint() {
		
		return "/comune";
	}
	
	@Test
	void getAllComuni() {
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tutticomuni", HttpMethod.GET,getAuthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		
	}
	@Test
	void getAllComuniKo() {
		ResponseEntity<String> r1 = restTemplate.exchange(api() + "/tutticomuni", HttpMethod.GET,getUnauthorizedEntity(),String.class);
		assertThat(r1.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	@Test
	void getAllComuniNotAuth() {
		ResponseEntity<String> r1 = restTemplate.exchange(api() + "/tutticomuni", HttpMethod.GET,HttpEntity.EMPTY,String.class);
		assertThat(r1.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	@Test
	void getAllComuneProvinceNome() {
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tutticomuninome/Na", HttpMethod.GET,getAuthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
	@Test
	void getAllComuneProvinceNomeKo() {
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tutticomuninome/Na", HttpMethod.GET,getUnauthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	@Test
	void getAllProvinceNomeNotFound() {
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tutticomuninome/", HttpMethod.GET,getAuthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.NOT_FOUND);
	}
	@Test
	void getAllProvinceNomeNotAuth() {
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tutticomuninome/na", HttpMethod.GET,HttpEntity.EMPTY,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	@Test
	void inserisciComune() {
		InserisciComuneRequestDTO dto = new InserisciComuneRequestDTO();
		dto.setCap("80021");
		dto.setNome("boh");
		dto.setSiglaProvincia("blAb");
		HttpEntity<	InserisciComuneRequestDTO>entity = new HttpEntity<	InserisciComuneRequestDTO>(dto,getAuthorizedHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/inseriscicomune",HttpMethod.POST,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		
	}
	@Test
	void inserisciComuneKo() {
		InserisciComuneRequestDTO dto = new InserisciComuneRequestDTO();
		dto.setCap("80021");
		dto.setNome("boh");
		dto.setSiglaProvincia("NA");	
		
		HttpEntity<	InserisciComuneRequestDTO>entity = new HttpEntity<	InserisciComuneRequestDTO>(dto,getUnauthorizedRoleHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/inseriscicomune",HttpMethod.POST,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
		
	}
	@Test
	void inserisciComuneNotAuth() {
		InserisciComuneRequestDTO dto = new InserisciComuneRequestDTO();
		dto.setCap("80021");
		dto.setNome("boh");
		dto.setSiglaProvincia("NA");	
		
		HttpEntity<	InserisciComuneRequestDTO>entity = new HttpEntity<	InserisciComuneRequestDTO>(dto);
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/inseriscicomune",HttpMethod.POST,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		
	}
	@Test
	void inserisciComuneNotFound() {
		InserisciComuneRequestDTO dto = new InserisciComuneRequestDTO();
		dto.setCap("80021");
		dto.setNome("boh");
		dto.setSiglaProvincia("notfound");	
		
		HttpEntity<	InserisciComuneRequestDTO>entity = new HttpEntity<	InserisciComuneRequestDTO>(dto,getAuthorizedHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/inseriscicomune",HttpMethod.POST,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.NOT_FOUND);
		
	}
	@Test
	void modificaComune() {
		ModificaComuneRequestDTO dto = new ModificaComuneRequestDTO();
		dto.setId(2L);
		dto.setCap("8002");
		dto.setSiglaProvincia("blAb");
		dto.setNome("boh");
		
		HttpEntity<	ModificaComuneRequestDTO>entity = new HttpEntity<ModificaComuneRequestDTO>(dto,getAuthorizedHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/modificacomune",HttpMethod.PUT,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		
	}
	@Test
	void modificaComuneKo() {
		ModificaComuneRequestDTO dto = new ModificaComuneRequestDTO();
		dto.setId(1L);
		dto.setCap("8002");
		dto.setSiglaProvincia("blAb");
		dto.setNome("boh");
		
		HttpEntity<	ModificaComuneRequestDTO>entity = new HttpEntity<ModificaComuneRequestDTO>(dto,getUnauthorizedRoleHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/modificacomune",HttpMethod.PUT,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
		
	}
	@Test
	void modificaComuneNotAuth() {
		ModificaComuneRequestDTO dto = new ModificaComuneRequestDTO();
		dto.setId(2L);
		dto.setCap("8002");
		dto.setSiglaProvincia("NA");
		dto.setNome("boh");
		
		HttpEntity<	ModificaComuneRequestDTO>entity = new HttpEntity<ModificaComuneRequestDTO>(dto);
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/modificacomune",HttpMethod.PUT,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		
	}
	@Test
	void modificaComuneNotFoundProvincia() {
		ModificaComuneRequestDTO dto = new ModificaComuneRequestDTO();
		dto.setId(1L);
		dto.setCap("8002");
		dto.setSiglaProvincia("bb");
		dto.setNome("boh");
		
		HttpEntity<	ModificaComuneRequestDTO>entity = new HttpEntity<ModificaComuneRequestDTO>(dto,getAuthorizedHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/modificacomune",HttpMethod.PUT,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.NOT_FOUND);
		
	}
	@Test
	void modificaComuneNotFoundComune() {
		ModificaComuneRequestDTO dto = new ModificaComuneRequestDTO();
		dto.setId(3333333333L);
		dto.setCap("8002");
		dto.setSiglaProvincia("NA");
		dto.setNome("boh");
		
		HttpEntity<	ModificaComuneRequestDTO>entity = new HttpEntity<ModificaComuneRequestDTO>(dto,getAuthorizedHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/modificacomune",HttpMethod.PUT,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.NOT_FOUND);
		
	}
	@Test
	void eliminaComune() {
		EliminaComuneRequestDTO dto = new EliminaComuneRequestDTO();
		dto.setId(1l);
		HttpEntity<	EliminaComuneRequestDTO >entity = new HttpEntity<EliminaComuneRequestDTO >(dto,getAuthorizedHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/eliminacomune",HttpMethod.DELETE,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
	@Test
	void eliminaComuneKo() {
		EliminaComuneRequestDTO dto = new EliminaComuneRequestDTO();
		dto.setId(1l);
		HttpEntity<	EliminaComuneRequestDTO >entity = new HttpEntity<EliminaComuneRequestDTO >(dto,getUnauthorizedRoleHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/eliminacomune",HttpMethod.DELETE,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
	}
	@Test
	void eliminaComuneNotAuth() {
		EliminaComuneRequestDTO dto = new EliminaComuneRequestDTO();
		dto.setId(1l);
		HttpEntity<	EliminaComuneRequestDTO >entity = new HttpEntity<EliminaComuneRequestDTO >(dto);
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/eliminacomune",HttpMethod.DELETE,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	@Test
	void eliminaComuneNotFound() {
		EliminaComuneRequestDTO dto = new EliminaComuneRequestDTO();
		dto.setId(2233333l);
		HttpEntity<	EliminaComuneRequestDTO >entity = new HttpEntity<EliminaComuneRequestDTO >(dto,getAuthorizedHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/eliminacomune",HttpMethod.DELETE,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.NOT_FOUND);
	}
	@Test
	void getAllComuneNome() {
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tutticomuninome/San_Costanzo", HttpMethod.GET,getAuthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
	@Test
	void getAllComuneNomeKo() {
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tutticomuninome/San_Costanzo", HttpMethod.GET,getUnauthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	@Test
	void getAllComuneNomeNotAuth() {
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tutticomuninome/San_Costanzo", HttpMethod.GET,HttpEntity.EMPTY,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	@Test
	void getAllComuneNomeNotFound() {
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tutticomuninome/", HttpMethod.GET,getAuthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.NOT_FOUND);
	}

}
