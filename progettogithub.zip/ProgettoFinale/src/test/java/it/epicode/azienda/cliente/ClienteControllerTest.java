package it.epicode.azienda.cliente;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import it.epicode.azienda.BasicTests;
import it.epicode.azienda.dto.EliminaClienteRequestDTO;
import it.epicode.azienda.dto.EliminaComuneRequestDTO;
import it.epicode.azienda.dto.InserisciComuneRequestDTO;
import it.epicode.azienda.dto.ModificaComuneRequestDTO;

public class ClienteControllerTest extends BasicTests {

	@Override
	protected String getEntryPoint() {
		
		return "/cliente"; 

}
	@Test
	void getAllClienti() {
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tutticlienti", HttpMethod.GET,getAuthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		
	}
	@Test
	void getAllClientiKo() {
		ResponseEntity<String> r1 = restTemplate.exchange(api() + "/tutticlienti", HttpMethod.GET,getUnauthorizedEntity(),String.class);
		assertThat(r1.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	@Test
	void getAllClientiNotAuth() {
		ResponseEntity<String> r1 = restTemplate.exchange(api() + "/tutticlienti", HttpMethod.GET,HttpEntity.EMPTY,String.class);
		assertThat(r1.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	@Test
	void getAllClientiProvinceNome() {
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tutticlientinome/luca", HttpMethod.GET,getAuthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
	@Test
	void getAllClientiProvinceNomeKo() {
		ResponseEntity<String> r = restTemplate.exchange(api() +  "/tutticlientinome/luca", HttpMethod.GET,getUnauthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	@Test
	void getAllClientiNomeNotFound() {
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tutticlientinome", HttpMethod.GET,getAuthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.NOT_FOUND);
	}
	@Test
	void getAllClientiNomeNotAuth() {
		ResponseEntity<String> r = restTemplate.exchange(api() +  "/tutticlientinome/luca", HttpMethod.GET,HttpEntity.EMPTY,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}


	@Test
	void eliminaCliente() {
		EliminaClienteRequestDTO dto = new EliminaClienteRequestDTO();
		dto.setId(1l);
		HttpEntity<	EliminaClienteRequestDTO >entity = new HttpEntity<EliminaClienteRequestDTO >(dto,getAuthorizedHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/eliminacliente",HttpMethod.DELETE,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
	@Test
	void eliminaClienteKo() {
		EliminaClienteRequestDTO dto = new EliminaClienteRequestDTO();
		dto.setId(1l);
		HttpEntity<	EliminaClienteRequestDTO >entity = new HttpEntity<EliminaClienteRequestDTO >(dto,getUnauthorizedRoleHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/eliminacliente",HttpMethod.DELETE,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
	}
	@Test
	void eliminaClienteNotAuth() {
		EliminaClienteRequestDTO dto = new EliminaClienteRequestDTO();
		dto.setId(1l);
		HttpEntity<	EliminaClienteRequestDTO >entity = new HttpEntity<EliminaClienteRequestDTO >(dto);
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/eliminacliente",HttpMethod.DELETE,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	@Test
	void eliminaComuneNotFound() {
		EliminaClienteRequestDTO dto = new EliminaClienteRequestDTO();
		dto.setId(2233333l);
		HttpEntity<	EliminaClienteRequestDTO >entity = new HttpEntity<EliminaClienteRequestDTO >(dto,getAuthorizedHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/eliminacliente",HttpMethod.DELETE,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.NOT_FOUND);
	}

	
}