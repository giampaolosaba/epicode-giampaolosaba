package it.data;

public class ContoCorrente {
private int numeroconto;
private String intestatario;
private float saldo;


public ContoCorrente() {}


public ContoCorrente(int numeroconto, String intestatario, float saldo) {
	
	this.numeroconto = numeroconto;
	this.saldo = saldo;
	this.intestatario = intestatario;

	
}


public int getNumeroconto() {
	return numeroconto;
}


public void setNumeroconto(int numeroconto) {
	this.numeroconto = numeroconto;
}


public String getIntestatario() {
	return intestatario;
}


public void setIntestatario(String intestatario) {
	this.intestatario = intestatario;
}


public float getSaldo() {
	return saldo;
}


public void setSaldo(float saldo) {
	this.saldo = saldo;
}

}
