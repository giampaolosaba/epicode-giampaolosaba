package it.data;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ContoCorrenteDAO {
	public  boolean controllaVersa(String operazione, int numeroconto, float saldo) {
		Connection connessione = ConnectionFactory.getConnection();
		String query = "SELECT * FROM contocorrente WHERE numeroconto = ?";
		PreparedStatement ps = null;
		
		int verifica = 0;
		try {
			ps = connessione.prepareStatement(query);
			ps.setInt(1,numeroconto);
			verifica = ps.executeUpdate();
		
		} catch (SQLException e) {

			e.printStackTrace();
		}
		
			try { ps.close(); } catch (SQLException e) { e.printStackTrace(); }
			try { connessione.close(); } catch (SQLException e) { e.printStackTrace(); }
		
		
		return true;
			
		
		
		
		
		

	}
	public  boolean controllaPreleva(String operazione, int numeroconto, float saldo) {
		Connection connessione = ConnectionFactory.getConnection();
		String query = "SELECT * FROM contocorrente WHERE numeroconto = ? AND saldo >= ? ";
		PreparedStatement ps = null;
		int verificaPreleva = 0;
		boolean verifica=false;
		try {
			ps = connessione.prepareStatement(query);
			ps.setInt(1,numeroconto);
			ps.setFloat(2,saldo);
			verificaPreleva = ps.executeUpdate();
		
		} catch (SQLException e) {

			e.printStackTrace();
		}
		finally {
			try { ps.close(); } catch (SQLException e) { e.printStackTrace(); }
			try { connessione.close(); } catch (SQLException e) { e.printStackTrace(); }
		}
		if(verificaPreleva > 0) {
			System.out.println("ok");
			return verifica=true;
		}
		else {
		
			System.out.println("nookpreleva");
			
		}
		return verifica=true;
		
	
		

	}
	

	public  ContoCorrente getContoCorrente(int numeroconto) {
		Connection connessione = ConnectionFactory.getConnection();
		
		try {
			PreparedStatement ps = null;
			boolean numupdate = false;
			String query = "SELECT * FROM contocorrente WHERE numeroconto = ?  ";
			ps = connessione.prepareStatement(query);
			ps.setInt(1,numeroconto);
			ResultSet rs = ps.executeQuery();
			ContoCorrente conto = new ContoCorrente();
			
			
			while(rs.next()) {
			numupdate = true;
			String intestatario = rs.getString("intestatario");
			Float saldo = rs.getFloat("saldo");
			conto = new ContoCorrente(numeroconto, intestatario, saldo);
			System.out.println(intestatario +"" + saldo + "");
				
			}
			return conto;
		} catch (SQLException e) {

			e.printStackTrace();
		}
		finally {
			
			try { connessione.close(); } catch (SQLException e) { e.printStackTrace(); }
		}
		return null;
	
		
		
		
		}
	public  boolean versa(int numeroconto, float saldo) {
		Connection connessione = ConnectionFactory.getConnection();

		String query = "update contocorrente set saldo = saldo  + ? where numeroconto = ? ";
		int num = 0;
		boolean versa = false;
		PreparedStatement ps = null;
		
		try {
			ps = connessione.prepareStatement(query);
			ps.setFloat(1, saldo);
			ps.setInt(2, numeroconto);
			num = ps.executeUpdate();
		

		} catch (SQLException e) {

			e.printStackTrace();
		}
		finally {
			try { ps.close(); } catch (SQLException e) { e.printStackTrace(); }
			try { connessione.close(); } catch (SQLException e) { e.printStackTrace(); }
		}
	
		
		
		if (num > 0 ) {
		
			return versa = true;
			
		}
		else {
			
			return versa = false;
		}
		
		 
		
		

	
	


	}

		public boolean preleva(int numeroconto, float saldo) {
			Connection connessione = ConnectionFactory.getConnection();

			String query = "update contocorrente set saldo = saldo - ? where numeroconto = ? and saldo >= ? ";
			PreparedStatement ps = null;
			boolean preleva = false;
			int controlloPreleva = 0;
			try {
				ps = connessione.prepareStatement(query);
				ps.setFloat(1, saldo);
				ps.setInt(2, numeroconto);
				ps.setFloat(3, saldo);
				
				controlloPreleva = ps.executeUpdate();

			} catch (SQLException e) {

				e.printStackTrace();
			}
			finally {
				try { ps.close(); } catch (SQLException e) { e.printStackTrace(); }
				try { connessione.close(); } catch (SQLException e) { e.printStackTrace(); }
			}
			
			if (controlloPreleva > 0 ) {
				
				return preleva = true;
				
			}
			else {
				
				
				return preleva = false;
			}
			
			
		}

		public   boolean esiste(int numeroconto) {
			Connection connessione = ConnectionFactory.getConnection();

			String query = "Select * from contocorrente where numeroconto = ?";
		
			PreparedStatement ps = null;
			boolean esiste = false;
			int controlloesiste = 0;
			try {
				ps = connessione.prepareStatement(query);
				
				ps.setInt(1, numeroconto);
			
				
				esiste = ps.execute();

			} catch (SQLException e) {

				e.printStackTrace();
			}
			finally {
				try { ps.close(); } catch (SQLException e) { e.printStackTrace(); }
				try { connessione.close(); } catch (SQLException e) { e.printStackTrace(); }
			}
			
			if (esiste = true ) {
				
				return true;
				
			}
			else {
				
				
				return  false;
			}
			
		
			
		
		}
		public boolean inserisciConto(int numeroconto, float saldo,String intestatario) {
			Connection connessione = ConnectionFactory.getConnection();
			String query = "INSERT INTO contocorrente (numeroconto, saldo, intestatario ) VALUES (?, ?, ?)";
			boolean inserisciI = false;
			int numup = 0;
			PreparedStatement ps = null;
			try {
				ps = connessione.prepareStatement(query);
				ps.setInt(1, numeroconto);
				ps.setFloat(2, saldo);
				ps.setString(3, intestatario);
				
				numup = ps.executeUpdate();
			} catch (SQLException e) {

				e.printStackTrace();
			} finally {
				try { ps.close(); } catch (SQLException e) { e.printStackTrace(); }
				try { connessione.close(); } catch (SQLException e) { e.printStackTrace(); }
			}
			if(numup > 0) {
				System.out.println("il conto � stato aggiunto");
				return true;
			}
			else {
				System.out.println("il conto non � stato aggiunto");
				return false;
			}
			
		
			}
}


