package it.presentation;
import it.business.*;
import it.data.ContoCorrente;
import jakarta.ejb.EJB;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Servlet implementation class MyServlet
 */


public class MyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */

	@EJB
	BancomatEJB bejb;


	public MyServlet() {
		super();
		
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String operazione = request.getParameter("operazione");
		int numeroconto = Integer.parseInt(request.getParameter("numeroconto"));
		float saldo = Float.parseFloat(request.getParameter("saldo"));


		boolean ok = false;
	


		String msg = "";
		switch(operazione) {
		case "preleva":
			ok =bejb.esiste(numeroconto);

			ok=bejb.controllaPreleva(operazione, numeroconto, saldo);

			ok=bejb.preleva(numeroconto, saldo);
			if(ok) {
		
				msg = "Prelievo andato a buon fine ," +" "+ "il conto di:"+" "+ bejb.getContoCorrente(numeroconto).getIntestatario()+" "+"è stato aggiornato con successo."+" "+"Il saldo aggiornato è "+bejb.getContoCorrente(numeroconto).getSaldo()+"$";;
			}
			else {
				msg="Abbiamo riscontrato un errore";
			}
			break;
		case "saldo":
			ok=	bejb.esiste(numeroconto);
			bejb.getContoCorrente(numeroconto);
			if(ok ) {
			
			msg = "Carissimo" + " "+ bejb.getContoCorrente(numeroconto).getIntestatario()+ " " + "Il tuo saldo disponibile ammonta a :" +" "+ bejb.getContoCorrente(numeroconto).getSaldo()+"$";
			
			}
			else {
				
				msg = "Conto inesistente";
				
			}
			 
			
			break;
		case "versa":
		ok=	bejb.esiste(numeroconto);

		ok=	bejb.controllaVersa(operazione, numeroconto, saldo);
		ok=	bejb.versa(numeroconto, saldo);
			if(ok) {
			
				msg = "Deposito andato a buon fine , "+" "+ "il conto di:"+" "+ bejb.getContoCorrente(numeroconto).getIntestatario()+" "+"è stato aggiornato con successo."+" "+"Il saldo aggiornato è "+bejb.getContoCorrente(numeroconto).getSaldo()+"$";
			}
			else {
				msg="Abbiamo riscontrato un errore";
			}
			break;
		}

		request.setAttribute("success", ok);
		request.setAttribute("messaggio", msg);
		request.setAttribute("operazione",operazione);
		request.setAttribute("numeroconto",numeroconto);
		request.setAttribute("saldo",saldo);

		request.getServletContext().getRequestDispatcher("/WEB-INF/jsp/contocorrente.jsp").forward(request, response);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);
	}

}
