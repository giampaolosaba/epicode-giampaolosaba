package it.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "Contatti")
@NamedQuery(name="cerca.contatti.per.cognome", query="SELECT c from Contatto c Like :cognome%")
@NamedQuery(name="cerca.contatti.per.numero", query ="SELECT c from Contatto c where num_telefono = :num_telefono")
public class Contatto implements Serializable{

	private int id;
	private String nome;
	private String cognome;
	private String email;
		
	private List<NumTelefono> numTelefoni = new ArrayList<NumTelefono>();
	
	public Contatto() {}

	public Contatto(String nome, String cognome, String email) {
		this.nome = nome;
		this.cognome = cognome;
		this.email = email;	
	}

	public Contatto(int id, String nome, String cognome, String email) {
		this.id = id;
		this.nome = nome;
		this.cognome = cognome;
		this.email = email;
	}
	
	@Id
	@Column(name = "id_contatto")
	@GeneratedValue(strategy = GenerationType.AUTO)
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	@Column(name = "nome")
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	@Column(name = "cognome")
	public String getCognome() {
		return cognome;
	}
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}
	
	@Column(name = "email")
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

	@ManyToOne
	@JoinColumn(name = "num_telefono")
	public List<NumTelefono> getNumTelefoni() {
		return numTelefoni;
	}

	public void setNumTelefoni(List<NumTelefono> numTelefoni) {
		this.numTelefoni = numTelefoni;
	}

	
	

	
	
	
	
	
	
	
	
}
