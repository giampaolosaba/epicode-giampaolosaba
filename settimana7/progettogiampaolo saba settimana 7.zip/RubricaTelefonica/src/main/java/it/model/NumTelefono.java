package it.model;


import java.io.Serializable;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "numeri_telefonici")
public class NumTelefono implements Serializable{
	
	private String numTelefono;	
	private Contatto contatto;
	

	public NumTelefono(String numTelefono) {
		this.numTelefono = numTelefono;
	}

	public NumTelefono() {}
	
	@Id
	@Column(name = "num_telefono")
	public String getNumTelefono() {
		return numTelefono;
	}
	public void setNumTelefono(String numTelefono) {
		this.numTelefono = numTelefono;
	}
	
	
	@OneToMany(mappedBy = "numTelefoni", cascade = CascadeType.ALL)	
	public Contatto getContatto() {
		return contatto;
	}
	public void setContatto(Contatto contatto) {
		this.contatto = contatto;
	}
	
	
	
	
	
	
	
}
