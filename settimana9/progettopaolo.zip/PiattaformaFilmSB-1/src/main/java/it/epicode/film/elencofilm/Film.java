package it.epicode.film.elencofilm;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;



import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
public class Film {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@NotNull(message = "il campo titolo è obbligatorio!")
	private String titolo;
	@NotNull(message = "il campo anno è obbligatorio!")
	private String anno;
	@NotNull(message = "il campo regista è obbligatorio!")
	private String regista;
	@NotNull(message = "il campo tipo è obbligatorio!")
	private String tipo;
	@NotNull(message = "il campo incasso è obbligatorio!")
	private String incasso;


}
