package it.epicode.film.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Service;

import it.epicode.film.dto.CercaFilmPerIdResponseDTO;
import it.epicode.film.dto.CercaFilmPerRegistaResponseDTO;
import it.epicode.film.dto.InserisciFilmRequestDTO;
import it.epicode.film.dto.ModificaFilmRequestDTO;
import it.epicode.film.elencofilm.Film;
import it.epicode.film.elencofilm.FilmRepository;

@Service
public class FilmService {
	@Autowired
	FilmRepository fr;
	
	
	/**
	 * inserimento nel db di un film attraverso il DTO
	 * @param c
	 * @param errori
	 * @return
	 */

	public boolean inserisciFilm(InserisciFilmRequestDTO dto) {
		Film f = new Film();


		f.setTitolo(dto.getTitolo());
		f.setAnno(dto.getAnno());
		f.setRegista(dto.getRegista());
		f.setTipo(dto.getTipo());
		String hash = BCrypt.hashpw(dto.getIncasso(), BCrypt.gensalt());
		f.setIncasso(hash);
		fr.save(f);
		return true;
	}
	
	/**
	 * ricerca di un film nel db attraverso l'id passato in input 
	 * 
	 * @param id
	 * @return
	 */

	public CercaFilmPerIdResponseDTO trovaTuttiIFilmPerId(int id) {
		CercaFilmPerIdResponseDTO dto = new  CercaFilmPerIdResponseDTO();

		dto.setFilmTrovato( fr.findById(id).get());
		return dto;
	}
/**
 * ritorna la lista di tutti i film con il regista passato in input
 * @param regista
 * @return
 */
	public ResponseEntity trovaTuttiIFilmPerRegista(String regista) {
		CercaFilmPerRegistaResponseDTO dto = new  CercaFilmPerRegistaResponseDTO();
		List<Film>lf = fr.findByRegista(regista) ;
		if(lf.size()>0) {
			dto.setRegista(regista);
			dto.setFilmTrovati(lf.size());
			dto.setListaFilm(lf);
			return ResponseEntity.ok(lf);}
		else {
			return new ResponseEntity("Regista non esiste nessun film trovato", HttpStatus.NOT_FOUND);
		}
		
		
		/**
		 * modifica un film presente nel db 
		 */
	}
	public boolean ModificaFilm(ModificaFilmRequestDTO dto) {
		if(fr.existsById(dto.getId())) {
			Film f = fr.findById(dto.getId()).get();
			f.setTitolo(dto.getTitolo());
			f.setAnno(dto.getAnno());
			f.setRegista(dto.getRegista());
			f.setTipo(dto.getTipo());
			String hash = BCrypt.hashpw(dto.getIncasso(), BCrypt.gensalt());
			f.setIncasso(hash);
			fr.save(f);
			return true;


		}
		else {return false;

		}
	}
}




