package it.epicode.film.dto;

import java.util.List;

import it.epicode.film.elencofilm.Film;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor

public class CercaFilmPerRegistaResponseDTO {
	private String regista;
	private int filmTrovati;
	private List<Film> listaFilm;

}
