package it.epicode.film.elencofilm;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
/**
 * repository classe film
 * @author Giovanni Guarnieri
 */
public interface FilmRepository extends CrudRepository<Film, Integer> {
	/**
	 * ricerca i film per regista in input il regista
	 * 
	 * @param regista
	 * @return una lista di film con il regista passato in input
	 */
	public List<Film> findByRegista(String regista);



}
