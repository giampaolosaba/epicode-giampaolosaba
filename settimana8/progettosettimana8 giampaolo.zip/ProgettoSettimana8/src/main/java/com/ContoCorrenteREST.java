package com;

import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import model.ContoCorrente;

@Path("/conto_corrente")
public class ContoCorrenteREST {

	private static List<ContoCorrente> conticorrenti = new ArrayList<>();


	@POST
	@Path("/inserimentocontocorrente")
	@Consumes (MediaType.APPLICATION_JSON)
	@Produces (MediaType.APPLICATION_JSON)
	public Response creaContoCorrente(ContoCorrente cc) {
		conticorrenti.add(cc);
		String result = "Creazione conto avvenuto con successo !";
		return Response.status(201).entity(result).build();

	}
	@PUT
	@Path("/aggiornacontocorrente")
	@Consumes (MediaType.APPLICATION_JSON)
	@Produces (MediaType.APPLICATION_JSON)
	public Response aggiornaContoCorrente(ContoCorrente cc) {
		String result = "";
		if(conticorrenti.contains(cc))
		{
			int index = conticorrenti.indexOf(cc);

			conticorrenti.set(index, cc);
			result= "Aggiornamento del conto avvenuto con successo";
			return Response.status(200).entity(result).build();
		}else {
			result ="aggiornamento non riuscito ";
			return Response.status(404).entity(result).build();
		}

	}
	//METODO PER PRELEVARE ATTRAVERSO L'USO DELL'ATTRIBUTO IBAN 
	@PUT
	@Path("/prelievo/{prelievo}")
	@Consumes (MediaType.APPLICATION_JSON)
	public Response prelievo(@PathParam("Prelievo") double saldoPrelievo, int iban) {
		String result = "";
		String operazione ="";
		for (ContoCorrente cc : conticorrenti) {
			if(iban == cc.getIban()) {
				if( saldoPrelievo<=cc.getSaldo() ) {

					cc.setSaldo( saldoPrelievo - cc.getSaldo());
					result= "Prelievo avvenuto con successo dal conto corrente";
					operazione ="prelievo";
					cc.listamovimenti(operazione, saldoPrelievo);

					return Response.status(200).entity(result).build();
				}  else {

					result ="Prelievo non riuscito dal conto corrente";
					return Response.status(404).entity(result).build();
				}  
			}

			result= "conto non trovato";
			return Response.status(404).entity(result).build();

		}
		return Response.status(404).entity(result).build();

	}

	@PUT
	@Path("/prelievo1/{prelievo1}")
	@Consumes (MediaType.APPLICATION_JSON)
	@Produces (MediaType.APPLICATION_JSON)
	public Response prelievo1(@PathParam("prelievo") double saldo, ContoCorrente cc) {
		String result = "";
		String operazione ="";
		if(conticorrenti.contains(cc))
		{
			int index = conticorrenti.indexOf(cc);
			if(saldo <= cc.getSaldo()) {
				cc.setSaldo(saldo - cc.getSaldo());
				conticorrenti.set(index, cc);
				result= "prelievo avvenuto con successo!"
						+ "Saldo prelevato: " + cc.getSaldo() ;
				operazione ="prelievo";
				cc.listamovimenti(operazione, saldo);


				return Response.status(200).entity(result).build();
			}
			else {
				result ="prelievo non riuscito ";
				return Response.status(404).entity(result).build();
			}



		}
		else {
			result = "ContoCorrente inesistente";
			return Response.status(404).entity(result).build();
		}

	}



	@PUT
	@Path("/versamento/{versamento}")
	@Consumes (MediaType.APPLICATION_JSON)
	@Produces (MediaType.APPLICATION_JSON)
	public Response versamento(@PathParam("versamento") double saldo, ContoCorrente cc) {
		String result = "";
		String operazione ="";
		if(conticorrenti.contains(cc))
		{
			int index = conticorrenti.indexOf(cc);
			if(saldo >= 0) {
				cc.setSaldo(saldo += cc.getSaldo());
				conticorrenti.set(index, cc);
				result= "Versamento avvenuto con successo!"
						+ "Saldo versato: " + cc.getSaldo() ;
				operazione ="versamento";
				cc.listamovimenti(operazione, saldo);

				return Response.status(200).entity(result).build();
			}
			else {
				result ="Versamento non riuscito ";
				return Response.status(404).entity(result).build();
			}



		}
		else {
			result = "ContoCorrente inesistente";
			return Response.status(404).entity(result).build();
		}

	}
	
	@GET
    @Path("/intestatario/{intestatario}")
    @Produces(MediaType.APPLICATION_JSON)
    public ContoCorrente ricercaPerIntestatario(@PathParam("intestatario") String intestatario ) {
        ContoCorrente cc1 = new ContoCorrente();
        for (ContoCorrente cc : conticorrenti) {
            if(cc.getIntestatario().equals(intestatario)) {
                cc1 = cc;
            }
        }
        return cc1;
    }
	
	@DELETE
	@Path("/{iban}")
	public Response elimina(@PathParam("iban") int iban) {
		String result = "";
		for (ContoCorrente cc : conticorrenti) {
			if(cc.getIban() == iban) {
				conticorrenti.remove(cc);
				result = "Eliminazione avvenuta con successo";
				return Response.status(200).entity(result).build();
			}
			else {
				result = "Eliminazione non avvenuta";
				return Response.status(404).entity(result).build();

			}

		}
		return null;
	}



	@GET
	@Path("/tutticonti")
	@Produces (MediaType.APPLICATION_JSON)
	public List<ContoCorrente> tutticonti(){
		return conticorrenti;
	}


}








