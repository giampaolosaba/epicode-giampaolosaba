package it.epicode.universita10.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.servlet.ModelAndView;

import it.epicode.universita10.model.Studente;
import it.epicode.universita10.services.UniversitaService;
import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class StudenteController {

	@Autowired
	UniversitaService us;
	
	@GetMapping("/home")
	public ModelAndView home() {
		log.info("siamo nella home");
		ModelAndView mv = new ModelAndView("home");
		return mv;
		
	}
	
	@GetMapping("/form-inseriscistudente")
	public ModelAndView formInserisciStudente() {
		log.info("siamo nella form-inserisci studente");
		ModelAndView mv = new ModelAndView("form-inseriscistudente", "studente", new Studente());
		mv.addObject("elencoCorso", us.getAllCorsi());
		return mv;
	}
	
	
	
	@PostMapping("/post-inseriscistudente")
	public ModelAndView postInserisciStudente(@Valid  @ModelAttribute Studente studente,BindingResult result) {
		
		if(result.hasErrors()) {
			
			return new ModelAndView("error",HttpStatus.BAD_REQUEST);
		}
		log.info("siamo nella post-inserisci studente");
		log.debug("i dati dell'utente sono " + " " + studente.getNome()+ " "+ studente.getMatricola());
		us.inserisciStudente(studente);
		
		ModelAndView mv = new ModelAndView("redirect:/elenco-studenti");
	
		
		return mv;
	}
	
	
	
	
	@GetMapping("/elenco-studenti")
	public ModelAndView elencoStudenti() {
		ModelAndView mv = new ModelAndView("elenco-studenti");
		mv.addObject("elencoStudenti", us.getAllStudenti());
		return mv;
	}
	
	
	
	
	
	
	
	
	
	@GetMapping("/form-modificastudente/{matricola}")
	public ModelAndView formModificaStudente(@PathVariable ("matricola") String matricola) {
		ModelAndView mv = new ModelAndView("form-modificastudente", "studente", us.TrovaStudenteid(matricola));
		mv.addObject("elencoCorso", us.getAllCorsi());
	
		
		return mv;
	}
	
	@GetMapping("/put-modificastudente")
	public ModelAndView postModificaStudente(@Valid @ModelAttribute Studente studente,BindingResult result) {
		if(result.hasErrors()) {
			return new ModelAndView("error",HttpStatus.BAD_REQUEST);
		}
		us.modificaStudente(studente);
		ModelAndView mv = new ModelAndView("redirect:/elenco-studenti");
		
		return mv;
	}
	
	
	

	
@GetMapping("/form-eliminastudente/{matricola}")	
public ModelAndView formEliminaStudente(@PathVariable ("matricola") String matricola) {
	ModelAndView mv = new ModelAndView("form-eliminastudente", "studente", us.TrovaStudenteid(matricola));
	mv.addObject("elencoStudenti", us.getAllStudenti());
	return mv;
}
@GetMapping("/delete-eliminastudente")
public ModelAndView deleteEliminaStudente( @Valid @ModelAttribute Studente studente,BindingResult result) {
	if(result.hasErrors()) {
		return new ModelAndView("error",HttpStatus.BAD_REQUEST);
	}
	us.eliminaStudente(studente);
	ModelAndView mv = new ModelAndView("redirect:/elenco-studenti");
	
	return mv;
}


}
	
	
	
	

	
	
	
	
	



