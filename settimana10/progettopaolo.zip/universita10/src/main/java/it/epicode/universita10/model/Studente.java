package it.epicode.universita10.model;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@Valid
public class Studente {
	
	@Id
	@NotBlank
	private String matricola;
	@NotBlank
	private String nome;
	@NotBlank
	private String cognome;
	@NotBlank
	private String dataDiNascita;
	@NotBlank
	private String email;
	@NotBlank
	private String indirizzo;
	@NotBlank
	private String cittaDiResidenza;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name ="codice_corso")
	private CorsoDiLaurea corso;

}
