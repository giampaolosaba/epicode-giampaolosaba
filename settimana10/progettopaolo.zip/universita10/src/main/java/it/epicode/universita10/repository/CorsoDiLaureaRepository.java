package it.epicode.universita10.repository;

import org.springframework.data.repository.CrudRepository;

import it.epicode.universita10.model.CorsoDiLaurea;

public interface CorsoDiLaureaRepository extends CrudRepository<CorsoDiLaurea, String> {

}
