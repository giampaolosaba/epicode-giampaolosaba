package it.epicode.universita10.repository;

import org.springframework.data.repository.CrudRepository;

import it.epicode.universita10.model.Studente;

public interface StudenteRepository extends CrudRepository<Studente, String> {

}
