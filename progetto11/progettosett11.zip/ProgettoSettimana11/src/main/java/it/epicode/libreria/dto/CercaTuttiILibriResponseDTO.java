package it.epicode.libreria.dto;

import java.util.List;

import it.epicode.libreria.model.Autore;
import it.epicode.libreria.model.Categoria;
import it.epicode.libreria.model.Libro;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CercaTuttiILibriResponseDTO {
	private int LibriTrovati;
	List<Libro>elencoLibri;

	

}
