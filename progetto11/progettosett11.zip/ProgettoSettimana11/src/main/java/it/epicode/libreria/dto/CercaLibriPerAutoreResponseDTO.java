package it.epicode.libreria.dto;

import java.util.List;

import it.epicode.libreria.model.Autore;
import it.epicode.libreria.model.Libro;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
public class CercaLibriPerAutoreResponseDTO {
	private int libriTrovati;
	private List<Libro> listaLibri;
	
	
}
