package it.epicode.libreria.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import it.epicode.libreria.model.Autore;
import it.epicode.libreria.model.Libro;

public interface LibroRepository extends JpaRepository<Libro, Long> {
	
	/**
	 * query per la ricerca di un libro attraverso l'id dell'autore
	 * @param id
	 * @return
	 */
	@Query("select l from Libro l join l.autori a where a.id_autore=?1")
	public List<Libro> findByAutore(Long id);
	
	/**
	 * query per la ricerca di un libro attraverso la categoria
	 * @param id
	 * @return
	 */
	@Query("select l from Libro l join l.categoria c where c.id_categoria=?1")
	public List<Libro>findByCategoria(Long id);
}
