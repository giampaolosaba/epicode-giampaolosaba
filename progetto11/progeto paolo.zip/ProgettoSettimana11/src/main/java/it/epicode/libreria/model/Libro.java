package it.epicode.libreria.model;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Generated;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.Setter;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class Libro {
	
	@Id
	@Setter(value = AccessLevel.NONE)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id_libro;
	@NotBlank(message = "il titolo e' obbligatorio")
	private String titolo;
	@NotNull(message = "inserire l'anno di pubblicazione")
	private int annoDiPubblicazione;
	@NotNull(message = "il prezzo è obbligatorio")
	private double prezzo;

	@ManyToMany(mappedBy = "", cascade = CascadeType.ALL)
	@JoinTable(name = "elenco_libri_autori", joinColumns = @JoinColumn(name = "id_libro", referencedColumnName="id_libro") , inverseJoinColumns = @JoinColumn(name = "id_autore",referencedColumnName="id_autore"))
	private List<Autore>autori = new ArrayList<>();

	@ManyToMany(mappedBy = "", cascade = CascadeType.ALL)
	@JoinTable(name = "elenco_libri_categoria", joinColumns = @JoinColumn(name = "id_libro",referencedColumnName="id_libro"), inverseJoinColumns = @JoinColumn(name = "id_categoria",referencedColumnName="id_categoria"))
	private List<Categoria>categoria = new ArrayList<>();
	}
