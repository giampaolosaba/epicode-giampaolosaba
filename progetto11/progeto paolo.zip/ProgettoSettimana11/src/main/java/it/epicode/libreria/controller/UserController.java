package it.epicode.libreria.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import it.epicode.libreria.dto.InserisciUserRequestDto;
import it.epicode.libreria.dto.InserisciUserRequestDto2;
import it.epicode.libreria.dto.ModificaUserRequestDTO;
import it.epicode.libreria.dto.disabilitaUserRequestDTO;
import it.epicode.libreria.errors.ElementAlreadyPresentException;
import it.epicode.libreria.errors.NotFoundException;
import it.epicode.libreria.impl.User;
import it.epicode.libreria.services.UserServiceSecondario;

@RestController
@RequestMapping("/user")
public class UserController {

	
	@Autowired
	UserServiceSecondario us;
	
	
	

	@Operation (summary = "registrazione di un nuovo user", description = "registrazione di un nuovo user con possibilita di scelta di uno o piu ruoli")
	@ApiResponse(responseCode = "200" , description = "user registrato con successo")
	@PostMapping("/registrazioneUser")
	public ResponseEntity registerUserDefault(@Valid @RequestBody InserisciUserRequestDto2 user) throws ElementAlreadyPresentException, NotFoundException {
		us.inserisciUtente(user);
		return ResponseEntity.ok("user registrato con successo");
	}
	
	@Operation (summary = "registrazione di un nuovo user", description = "registrazione di un nuovo user con il ruolo di default")
	@ApiResponse(responseCode = "200" , description = "user registrato con successo")
	@PostMapping("/registrazioneUserConRuoloUser")
	public ResponseEntity registerUser(@Valid @RequestBody InserisciUserRequestDto user) throws ElementAlreadyPresentException {
		us.inserisciRuoloUser(user);
		return ResponseEntity.ok("user registrato con successo");
	}
	
	@Operation (summary = "registrazione di un nuovo user ", description = "registrazione di un nuovo user con il ruolo admin di default")
	@ApiResponse(responseCode = "200" , description = "admin registrato con successo")
	@PostMapping("/registrazioneAdmin")
	public ResponseEntity registerAdmin(@Valid @RequestBody InserisciUserRequestDto user) throws ElementAlreadyPresentException {
		us.inserisciAdmin(user);
		return ResponseEntity.ok("Admin registrato con successo");
	}
	

	
	@Operation (summary = "modifica di un user presente nel db", description = "modifica di un user presente nel db")
	@ApiResponse(responseCode = "200" , description = "utente modificato con successo ")
	@ApiResponse(responseCode ="401,403" , description = "Not Authenticated or you may have not role for this! ")
	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@PutMapping("/modificaUser")
	public ResponseEntity modificaUser(@Valid @RequestBody ModificaUserRequestDTO user) throws NotFoundException {
		us.modificaUser(user);
		return ResponseEntity.ok("utente modificato");
	}
	
	@Operation (summary = "elimanazione di un user presente nel db", description = "eliminazione di un user presente nel db")
	@ApiResponse(responseCode = "200" , description = "utente eliminato con successo ")
	@ApiResponse(responseCode ="401,403" , description = "Not Authenticated or you may have not role for this! ")
	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@DeleteMapping("/eliminaUser/{id}")
	public ResponseEntity eliminaUser(@PathVariable("id") Long id ) throws NotFoundException {
		us.eliminaUser(id);
		return ResponseEntity.ok("User eliminato");
	}
	
	@Operation (summary = "ritorna la lista degli user presenti nel db ", description = "elenco utenti presenti nel db")
	@ApiResponse(responseCode = "200" , description = "elenco utenti ")
	@ApiResponse(responseCode ="401" , description = "Not Authenticated or you may have not role for this! ")
	//@PreAuthorize("isAuthenticated()")
	//@SecurityRequirement(name = "bearerAuth")
	@GetMapping("/tuttiGliUtenti")
	public ResponseEntity trovaTuttiGliUtenti() {
		return ResponseEntity.ok(us.trovaTuttiGliUser());
	}
	
	@Operation (summary = "disabilita l'account di uno user ", description = "disabilita un'account")
	@ApiResponse(responseCode = "200" , description = "account disabilitato ")
	@ApiResponse(responseCode ="401,403" , description = "Not Authenticated or you may have not role for this! ")
	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@PutMapping("/disabilitaUser")
	public ResponseEntity disabilitaUser(@Valid @RequestBody disabilitaUserRequestDTO user) throws NotFoundException {
		us.disabilitaUser(user);
		return ResponseEntity.ok("account disabilitato");
	}
	
	
	@Operation (summary = "attiva l'account di uno user ", description = "attivazione un'account")
	@ApiResponse(responseCode = "200" , description = "account attivato ")
	@ApiResponse(responseCode ="401,403" , description = "Not Authenticated or you may have not role for this! ")
	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@PutMapping("/attivaUser")
	public ResponseEntity attivaUser(@Valid @RequestBody disabilitaUserRequestDTO user) throws NotFoundException {
		us.disabilitaUser(user);
		return ResponseEntity.ok("account attivato");
	}
}
