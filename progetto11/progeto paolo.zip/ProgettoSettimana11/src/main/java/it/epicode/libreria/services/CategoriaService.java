package it.epicode.libreria.services;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.epicode.libreria.dto.CercaTutteLeCategorieResponseDTO;
import it.epicode.libreria.dto.CercaTuttiGliAutoriResponseDTO;
import it.epicode.libreria.dto.InserisciCategoriaRequestDto;
import it.epicode.libreria.dto.ModificaAutoreRequestDTO;
import it.epicode.libreria.dto.ModificaCategoriaRequestDTO;
import it.epicode.libreria.errors.NotFoundException;
import it.epicode.libreria.model.Autore;
import it.epicode.libreria.model.Categoria;
import it.epicode.libreria.repository.CategoriaRepository;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class CategoriaService {
	@Autowired
	CategoriaRepository cr;
	
	/**
	 * inserimento di una categoria
	 * @param dto
	 */
	public void inserisciCategoria(InserisciCategoriaRequestDto dto) {
		log.info("siamo nell'inserimento categoria");
		Categoria c = new Categoria();
		BeanUtils.copyProperties(dto, c);
		cr.save(c);
		
	}
	
	
	/**
	 * ricerca di tutte le categorie presenti nel db
	 * @return
	 */
	public CercaTutteLeCategorieResponseDTO trovaTutteLeCategorie() {
		log.info("siamo nel trova tutte le categoria");
		CercaTutteLeCategorieResponseDTO  dto = new CercaTutteLeCategorieResponseDTO();
		List<Categoria> lc = (List)cr.findAll(); 
		if(lc.size()> 0) {
		dto.setCategorieTrovate(lc.size());;
		dto.setListaCategorie(lc);
			return dto;
		}
		return null;
	
	}
	
	/**
	 * modifica di una categoria
	 * @param dto
	 * @throws NotFoundException
	 */
	public void modificaCategoria(ModificaCategoriaRequestDTO dto) throws NotFoundException {
		log.info("siamo nel modifica categoria");
		if(cr.existsById(dto.getId_categoria())){
			Categoria c = cr.findById(dto.getId_categoria()).get();
			BeanUtils.copyProperties(dto, c);
			cr.save(c);
			}
		else { throw new NotFoundException("categoria non trovata");
			
		}
	}
	
	
	
	/** 
	 * eliminazione di una categoria
	 * @param id
	 * @throws NotFoundException
	 */
	public void eliminaCategoria(Long id) throws NotFoundException {
		log.info("siamo nell'elimina categoria");
		if(cr.existsById(id)) {
			cr.deleteById(id);
			
		}
		else{ throw new NotFoundException("Categoria inesistente");}

	}
}
