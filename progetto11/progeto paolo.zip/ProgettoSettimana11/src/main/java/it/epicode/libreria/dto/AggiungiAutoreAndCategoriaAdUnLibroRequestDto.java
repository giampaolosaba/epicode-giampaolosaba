package it.epicode.libreria.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class AggiungiAutoreAndCategoriaAdUnLibroRequestDto {
	@NotNull
	private Long id_libro;
	@NotNull
	private String autore;
	@NotNull
	private String categoria;

	
}
