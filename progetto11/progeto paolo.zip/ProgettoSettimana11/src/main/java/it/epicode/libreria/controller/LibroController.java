package it.epicode.libreria.controller;

import java.util.NoSuchElementException;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import it.epicode.libreria.dto.InserisciCategoriaRequestDto;
import it.epicode.libreria.dto.InserisciLibroRequestDto;
import it.epicode.libreria.dto.ModificaAutoreRequestDTO;
import it.epicode.libreria.dto.ModificaCategoriaRequestDTO;
import it.epicode.libreria.dto.ModificaLibroRequestDTO;

import it.epicode.libreria.dto.AggiungiAutoreAndCategoriaAdUnLibroRequestDto;
import it.epicode.libreria.errors.NotFoundException;
import it.epicode.libreria.services.LibroService;

@RestController
@RequestMapping("/libro")
public class LibroController {
	@Autowired
	LibroService ls;
	
	@Operation (summary = "inserisci un libro  nel db", description = "inserimento di un libro ")
	@ApiResponse(responseCode = "200" , description = "inserimento avvenuto con successo")
	@ApiResponse(responseCode ="401,403" , description = "Not Authenticated or you may have not role for this! ")
	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@PostMapping(path = "/inserisciLibro" ,produces = MediaType.TEXT_PLAIN_VALUE)
	public ResponseEntity inserisciLibro(@Valid @RequestBody InserisciLibroRequestDto dto)  {
		ls.inserisciLibro(dto);
		return ResponseEntity.ok("libro inserito");}

	@Operation (summary = "ritorna una lista di liri presenti nel db", description = "ritorna una lista di liri presenti nel db ")
	@ApiResponse(responseCode = "200" , description = "elenco libri")
	@ApiResponse(responseCode ="401" , description = "Not Authenticated ")
	//@PreAuthorize("isAuthenticated()")
	//@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("/tuttilibri")
	public ResponseEntity tuttiILibri() {
		return ResponseEntity.ok(ls.trovaTuttiLibri());
	}


	@Operation (summary = "aggiungi una categoria ed un autore ad un libro gia esistente  nel db", description = "aggiunta di una categoria ed un autore ad un libro esistente")
	@ApiResponse(responseCode = "200" , description = "aggiunta avvenuta con successo")
	@ApiResponse(responseCode ="401,403" , description = "Not Authenticated or you may have not role for this! ")
	//@PreAuthorize("hasRole('ADMIN')")
	//@SecurityRequirement(name = "bearerAuth")
	@PutMapping("/aggiugiAutoreAndCategoriaLibro")
	public ResponseEntity aggiungiAutoreAndCategoriaAdUnLibro(@Valid @RequestBody AggiungiAutoreAndCategoriaAdUnLibroRequestDto dto) throws NotFoundException {
		ls.aggiungiAutoreAndCategoriaAdUnLibro(dto);
		return ResponseEntity.ok("libro aggiornato");
	}


	@Operation (summary = "eliminazione di un libro presente db", description = "eliminazione di un libro presente db")
	@ApiResponse(responseCode = "200" , description = "eliminazione avvenuta con successo ")
	@ApiResponse(responseCode ="401,403" , description = "Not Authenticated or you may have not role for this! ")
	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@DeleteMapping("/eliminaLibro/{id}")
	public ResponseEntity eliminaLibro(@PathVariable("id") Long id ) throws NotFoundException {
		ls.eliminaLibro(id);
		return ResponseEntity.ok("Libro eliminato");
	}


	@Operation (summary = "modifica di un libro presente db", description = "modifica di un libro presente db")
	@ApiResponse(responseCode = "200" , description = "modifica avvenuta con successo ")
	@ApiResponse(responseCode ="401,403" , description = "Not Authenticated or you may have not role for this! ")
	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@PutMapping("/modificaLibro")
	public ResponseEntity modificaLibro(@RequestBody ModificaLibroRequestDTO dto)  {
		ls.modificaLibro(dto);
		return ResponseEntity.ok("libro modificato");
	}

	
	@Operation (summary = "ricerca di un libro presente db tramite id dell'autore ", description = "ricerca di un libro presente db tramite id dell'autore")
	@ApiResponse(responseCode = "200" , description = "elenco libro ")
	@ApiResponse(responseCode ="401" , description = "Not Authenticated")
	@PreAuthorize("isAuthenticated()")
	@SecurityRequirement(name = "bearerAuth")
	@GetMapping("/cercaAutore/{id}")
	public ResponseEntity tuttiILibriPerAutore(@PathVariable Long id) {
		return ResponseEntity.ok(ls.trovaTuttiLibriPerAutore(id));
	}
	
	
	@Operation (summary = "ricerca di un libro presente db tramite id della categoria ", description = "ricerca di un libro presente db tramite id della categoria")
	@ApiResponse(responseCode = "200" , description = "elenco libro ")
	@ApiResponse(responseCode ="401" , description = "Not Authenticated")
	@PreAuthorize("isAuthenticated()")
	@SecurityRequirement(name = "bearerAuth")
	@GetMapping("/cercaCategoria/{id}")
	public ResponseEntity tuttiILibriPerCategoria(@PathVariable Long id) {
		return ResponseEntity.ok(ls.trovaTuttiLibriPerCategoria(id));
	}


}
