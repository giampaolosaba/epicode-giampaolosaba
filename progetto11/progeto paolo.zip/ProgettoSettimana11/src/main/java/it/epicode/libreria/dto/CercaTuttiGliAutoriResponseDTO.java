package it.epicode.libreria.dto;

import java.util.List;

import it.epicode.libreria.model.Autore;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
public class CercaTuttiGliAutoriResponseDTO {
	private int AutoriTrovati;
	List<Autore>elencoAutori;
}
