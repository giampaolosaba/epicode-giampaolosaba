package it.epicode.libreria.services;



import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import it.epicode.libreria.dto.AggiungiAutoreAndCategoriaAdUnLibroRequestDto;
import it.epicode.libreria.dto.CercaLibriPerAutoreResponseDTO;
import it.epicode.libreria.dto.CercaLibriPerCategoriaResponseDTO2;
import it.epicode.libreria.dto.CercaTuttiILibriResponseDTO;
import it.epicode.libreria.dto.InserisciLibroRequestDto;
import it.epicode.libreria.dto.ModificaAutoreRequestDTO;
import it.epicode.libreria.dto.ModificaCategoriaRequestDTO;
import it.epicode.libreria.dto.ModificaLibroRequestDTO;

import it.epicode.libreria.errors.NotFoundException;
import it.epicode.libreria.impl.Role;
import it.epicode.libreria.model.Autore;
import it.epicode.libreria.model.Categoria;
import it.epicode.libreria.model.Libro;
import it.epicode.libreria.repository.AutoreRepository;
import it.epicode.libreria.repository.CategoriaRepository;
import it.epicode.libreria.repository.LibroRepository;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class LibroService {
	@Autowired
	LibroRepository lr;
	@Autowired
	AutoreRepository ar;
	@Autowired
	CategoriaRepository cr;
	

	
	/**
	 * inserimento di un libro 
	 * @param dto
	 * @throws NoSuchElementException
	 */
	public void inserisciLibro(InserisciLibroRequestDto dto) throws NoSuchElementException {
		log.info("siamo nell'inserisci libro");
		Libro l = new Libro();
		BeanUtils.copyProperties(dto, l);
	       String elencoAutori = dto.getAutore();
           String[]listaIdAutori=elencoAutori.split(",");
           List<Autore>ls = new ArrayList<Autore>();
           for(int i= 0; i<listaIdAutori.length; i++) {
           	Long idAutore= Long.parseLong(listaIdAutori[i]);
           	Autore a = ar.findById(idAutore).get();
           	if(a != null) {
           	a.getLibri().add(l);
           	ls.add(a);
           	}
           	else {
               	throw new NoSuchElementException("autore inesistente");
               }
           }
           String elencoCategoria = dto.getCategoria();
           String[]listaIdCategoria=elencoCategoria.split(",");
           List<Categoria>lc = new ArrayList<Categoria>();
           for(int i= 0; i<listaIdCategoria.length; i++) {
           	Long idCategoria= Long.parseLong(listaIdCategoria[i]);
           	Categoria c = cr.findById(idCategoria).get();
           	if(c!= null) {
           	c.getLibri().add(l);
           	lc.add(c);
           	}
           	else {
               	throw new NoSuchElementException("categoria inesistente");
               }
           }
           l.setCategoria(lc);
           l.setAutori(ls);
           lr.save(l);

	}
		

	
	/**
	 * ricerca di tutti i libri presenti
	 * @return
	 */
	public CercaTuttiILibriResponseDTO trovaTuttiLibri() {
		log.info("siamo nel trova tutti i libri");
		CercaTuttiILibriResponseDTO dto = new CercaTuttiILibriResponseDTO ();
		List<Libro> lc = (List)lr.findAll(); 
		if(lc.size()> 0) {
			dto.setLibriTrovati(lc.size());
			dto.setElencoLibri(lc);
			return dto;
		}
		else {
			new ResponseEntity("nessuna citta trovato", HttpStatus.NOT_FOUND);
			return null;
		}
	}
	
	
	/**
	 * associazione di un autore ed una categoria ad un libro gia esistente
	 * @param dto
	 * @throws NotFoundException
	 */
	public void aggiungiAutoreAndCategoriaAdUnLibro(AggiungiAutoreAndCategoriaAdUnLibroRequestDto dto) throws NotFoundException {
		log.info("siamo nell'aggiungi libro e categoria");
		if(lr.existsById(dto.getId_libro())){
			Libro l= lr.findById(dto.getId_libro()).get();
            BeanUtils.copyProperties(dto, l);
            String elencoAutori = dto.getAutore();
            String[]listaIdAutori=elencoAutori.split(",");
            List<Autore>ls = new ArrayList<Autore>();
            for(int i= 0; i<listaIdAutori.length; i++) {
            	Long idAutore= Long.parseLong(listaIdAutori[i]);
            	Autore a = ar.findById(idAutore).get();
            	if(a != null && !l.getAutori().contains(a)) {
            	a.getLibri().add(l);
            	ls.add(a);
            	}
            	else {
                	throw new NotFoundException("autore gia esistente o non trovato");
                }
            }
            String elencoCategoria = dto.getCategoria();
            String[]listaIdCategoria=elencoCategoria.split(",");
            List<Categoria>lc = new ArrayList<Categoria>();
            for(int i= 0; i<listaIdCategoria.length; i++) {
            	Long idCategoria= Long.parseLong(listaIdCategoria[i]);
            	Categoria c = cr.findById(idCategoria).get();
            	if(c!= null && !l.getCategoria().contains(c) ) {
            	c.getLibri().add(l);
            	lc.add(c);
            	}
            	else {
                	throw new NotFoundException("categoria gia esistente o non trovato");
                }
            }
            l.getAutori().addAll(ls);
            l.getCategoria().addAll(lc);
            lr.save(l);

	}
		
		else {
		throw new NoSuchElementException("libro inesistente");
	}
		
		
	}
	
	
	/**
	 * modifica di un libro
	 * @param dto
	 * @throws NotFoundException 
	 */
public void modificaLibro(ModificaLibroRequestDTO dto) throws NoSuchElementException{
	log.info("siamo nel modifica libro");
		if(lr.existsById(dto.getId_libro())){
			Libro l= lr.findById(dto.getId_libro()).get();
            BeanUtils.copyProperties(dto, l);
            String elencoAutori = dto.getAutore();
            String[]listaIdAutori=elencoAutori.split(",");
            List<Autore>ls = new ArrayList<Autore>();
            for(int i= 0; i<listaIdAutori.length; i++) {
            	Long idAutore= Long.parseLong(listaIdAutori[i]);
            	Autore a = ar.findById(idAutore).get();
            	if(a != null) {
            	a.getLibri().add(l);
            	ls.add(a);
            	}
            	else {
                	throw new NoSuchElementException("autore inesistente");
                }
            }
            String elencoCategoria = dto.getCategoria();
            String[]listaIdCategoria=elencoCategoria.split(",");
            List<Categoria>lc = new ArrayList<Categoria>();
            for(int i= 0; i<listaIdCategoria.length; i++) {
            	Long idCategoria= Long.parseLong(listaIdCategoria[i]);
            	Categoria c = cr.findById(idCategoria).get();
            	if(c != null) {
            	c.getLibri().add(l);
            	lc.add(c);
            	}
            	else {
                	throw new NoSuchElementException("categoria inesistente");
                }
            }
            l.setCategoria(lc);
            l.setAutori(ls);
            lr.save(l);

	}
		
		else {
		throw new NoSuchElementException("libro inesistente");
	}
		}
	
	
	/**
	 * eliminazione di un libro
	 * @param id
	 * @throws NotFoundException
	 */
	public void eliminaLibro(Long id) throws NotFoundException {
		log.info("siamo nell'elimina libro");
		if(lr.existsById(id)) {
			lr.deleteById(id);
			
		}
		else{ throw new NotFoundException("libro inesistente");}

	}
	
	
	/**
	 * ricerca dei libri per autore
	 * @param id
	 * @return
	 */
	public CercaLibriPerAutoreResponseDTO trovaTuttiLibriPerAutore(Long id) {
		log.info("siamo nel trova tutti i libri per autore");
		CercaLibriPerAutoreResponseDTO dto = new CercaLibriPerAutoreResponseDTO();
		List<Libro>lb = (List)lr.findByAutore(id);
		if(lb.size() > 0) {
			dto.setListaLibri(lb);
			dto.setLibriTrovati(lb.size());
			return dto;
		}
		return dto;
	}
	
	/**
	 * ricerca dei libri per categoria
	 * @param id
	 * @return
	 */
	public  CercaLibriPerCategoriaResponseDTO2 trovaTuttiLibriPerCategoria(Long id) {
		log.info("siamo nel trova tutti i libri");
		 CercaLibriPerCategoriaResponseDTO2 dto = new  CercaLibriPerCategoriaResponseDTO2();
		List<Libro>lb = (List)lr.findByCategoria(id);
		if(lb.size() > 0) {
			dto.setListaLibri(lb);
			dto.setLibriTrovati(lb.size());
			return dto;
		}
		return dto;
	}
	
	
	
}
	
	

	
	
	
	
	
	
	
	
	

