package it.epicode.libreria.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ModificaCategoriaRequestDTO {
	@NotNull
	private Long id_categoria;
	@NotBlank
	private String nome;
	
	
	
}
